 <!-- Load font awesome icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="navmenustyle.css">


<!-- The navigation menu -->
<div class="navbar1">
  <div class="subnav">
    <button class="subnavbtn">Sales Order<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#">New Sales Order</a>
 <a href="#">Sales Order History</a>
    </div>
  </div>
   <div class="subnav">
    <button class="subnavbtn">Job Order<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#">New Job Order</a>
 <a href="#">Job Order History</a>
    </div>
  </div>
  <div class="subnav">
    <button class="subnavbtn">Gatepass<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#">Gatepass History</a>
    </div>
  </div>
  <div class="subnav">
    <button class="subnavbtn">Inventory<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="coillist.php">Coil List</a>
	  <a href="bendedlist.php">Bended List</a>
	  <a href="misclist.php">Misc List</a>
    </div>
  </div>

</div> 
