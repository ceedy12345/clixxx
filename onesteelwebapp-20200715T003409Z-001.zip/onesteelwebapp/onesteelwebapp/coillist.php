 <html>
<head>
<script src="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.css" rel="stylesheet">
<link rel="stylesheet" href="scripts/bootstrap.min.css">
<script src="scripts/jquery-3.2.1.slim.min.js" ></script>
<script src="scripts/popper.min.js"></script>
<script src="scripts/bootstrap.min.js"></script>
<script src="scripts/jquery.min.js"></script>
</head>
	
	<?php
require_once("coilconfig.php");


?>
<?php include("navmenu.php"); ?>
	<div class="row">
	<form class="form-control" method="post" enctype="multipart/form-data">
	<table>
	<tr>
	<th>	Search by Coil No:</th><th><input type="text" name="search" id="search" class="form-control"></th>
	<th><td><input type="submit" name="searchbtn" class="btn btn-info" value="Search" ></td>
		<td><a href="coillist.php" class="btn btn-danger" name="clearbtn">Clear</a></td>
		<td><button type="button" data-toggle="modal" data-target="#addinventorymodal" class="btn btn-success">Add</button></td></th>
	</tr>
	</table>
	</form>
	</div></div>
<div class="col" style="overflow:auto; height:500px;" >
	<table class="table" style="overflow:auto;">
	
	 <thead>
    <tr>
	 <th scope="col">Date Recieved</th>
	 <th scope="col">CoilNo</th>
      <th scope="col">Color</th>
	  <th scope="col">Remarks</th>
	  <th scope="col">Yield</th>
      <th scope="col">Thickness</th>
	  <th scope="col">Width</th>
	  <th scope="col">Beg. Length</th>
	  <th scope="col">Rem. Length</th>
	  <th scope="col">Beg. Weight</th>
	  <th scope="col">Rem. Weight</th>
	  <th scope="col">Delete<th>
	
    </tr>
	<tbody>
	<?php
	while($row  = mysqli_fetch_array($results)){ ?>
		<tr>
		<td><?php echo $row['DateReceived']?></td>
		<td><?php echo $row['Coilno']?></td>
		<td><?php echo $row['Color']?></td>
		<td><?php echo $row['Remarks']?></td>
		<td><?php echo $row['Yield']?></td>
		<td><?php echo $row['Thickness']?></td>
		<td><?php echo $row['Width']?></td>
		<td><?php echo $row['BeginningLengthM']?></td>
		<td><?php echo $row['RemainingLengthM']?></td>
		<td><?php echo $row['BeginningWeightTon']?></td>
		<td><?php echo $row['ActualWeightTon']?></td>

		<td><a href="coillist.php?delete=<?php echo $row['id']?>" class="btn btn-danger">Delete</a></td>
		
		</tr>
	<?php } ?>
	
	</tbody>
	</table>
	
	<div>
	
	 <div class="modal fade" id="addinventorymodal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		<h4 class="modal-title">Coil Inventory</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <div class="container">
		<form class="form-control" method="post" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		Date Recieved:<br>
		<input type="date" name="daterec" id="daterec" class="form-control" ><br>
		Coilno:<br>
		<input type="text" name="Coilno" id="Coilno" class="form-control" ><br>
		Color:<br>
		<select name="Color" id="Color" class="form-control">
		<option value="Red Dragon">Red Dragon</option>
		<option value="Bloody Red">Bloody Red</option>
		<option value="Cozy Blue">Cozy Blue</option>
		<option value="Charcoal Gray">Charcoal Gray</option>
		<option value="Choco Brown">Choco Brown</option>
		<option value="Foam Green">Foam Green</option>
		<option value="Jade Green">Jade Green</option>
		<option value="Terracotta">Terracotta</option>
		<option value="Pearl White">Pearl White</option>
		<option value="Ivory">Ivory</option>
		<option value="G.I.">G.I.</option>
		<option value="B.I.">B.I.</option>
		<option value="S/S MATT 304">S/S MATT 304</option>
		<option value="S/S MIRROR 304">S/S MIRROR 304</option>
		
		
		</select><br>
		Remarks:<br>
		<select name="remarks" id="remarks" class="form-control">
		<option value="New Coil">New Coil</option>
		<option value="Used Coil">Used Coil</option>

		
		
		</select><br>
		
		
		Thickness:<br>
		<input type="text" name="thickness" id="thickness" class="form-control" ><br>
		Width:<br>
		<input type="text" name="width" id="width" class="form-control" ><br>

		BeginningLength:<br>
		<input type="text" name="beglength" id="beglength" class="form-control" ><br>
	BeginningWeight:<br>
		<input type="text" name="begweight" id="begweight" class="form-control" ><br>
	Yield:<br>
		<input type="text" name="yield" id="yield" class="form-control" ><br>

		
		
		
		<?php  
		if($update == true):		
		?>
		<input type="submit" name="update" class="btn btn-info" value="Update" >
		<a href="coillist.php?clear" class="btn btn-danger">Cancel</a>
		<?php else: ?>
		<input type="submit" name="submit" class="btn btn-primary" value="Add" >
		<a href="coillist.php?clear" class="btn btn-danger">Clear</a>
		<?php endif ?>
		
		
		<br>
		</form>		
		 
		 
    </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>