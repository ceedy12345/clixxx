<?php
require_once("serverconfig.php");
$results = mysqli_query($db, 'SELECT * FROM inventorylist ORDER BY id DESC');	

$update = false;

if(isset($_POST['submit'])){

			$daterec=$_POST['daterec'];
			$coilno=$_POST['Coilno'];
			$Color=$_POST['Color'];
			$Thickness=$_POST['thickness'];
			$Width=$_POST['width'];
			$Yield=$_POST['yield'];
			$beglength=$_POST['beglength'];
			$begweight=$_POST['begweight'];
			$remarks=$_POST['remarks'];
	
	$query = "INSERT INTO inventorylist (DateReceived, Color, Coilno, Thickness, Width, BeginningLengthM,BeginningWeightTon,Yield,Remarks) VALUES ('$daterec','$coilno', '$Color', '$Thickness', '$Width', '$beglength', '$begweight', '$Yield', '$remarks')";
	
	
	
	mysqli_query($db, $query);
	
	$_SESSION['message'] = 'Item Saved';
	$_SESSION['msg_type'] = 'success';
	
	header("location:coillist.php");
	exit();
}

	
	
	if(isset($_GET['delete'])){
		$id = $_GET['delete'];
		
		
		
	
		mysqli_query($db, "DELETE FROM inventorylist WHERE id='$id'");
		
		$_SESSION['message'] = 'Item Deleted';
		$_SESSION['msg_type'] = 'danger';
	
		
		header("location:coillist.php");
		exit();
	}


?>