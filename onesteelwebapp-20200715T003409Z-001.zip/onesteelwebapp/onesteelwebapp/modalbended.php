<?php
require_once("serverconfig.php");

$results = mysqli_query($db, 'SELECT * FROM bendedlist');	

?>
 <div class="modal fade" id="bendedinventorymodal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		<h4 class="modal-title">Bended Inventory</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <div class="container">
		  	<table class="table" style="overflow:auto;">
	
	 <thead>
    <tr>
	 <th scope="col">Id</th>
      <th scope="col">Color</th>
	  <th scope="col">Item Name</th>
	  <th scope="col">Quantity</th>
      <th scope="col">Thickness</th>
	  <th scope="col">Width</th>
	  <th scope="col">Length</th>
	  <th scope="col">Coil Yield</th>


	
    </tr>
	<tbody>
	<?php
	while($row  = mysqli_fetch_array($results)){ ?>
		<tr>
		<td><?php echo $row['id']?></td>
		<td><?php echo $row['Color']?></td>
		<td><?php echo $row['itemName']?></td>
		<td><?php echo $row['quantity']?></td>
		<td><?php echo $row['thickness']?></td>
		<td><?php echo $row['width']?></td>
		<td><?php echo $row['length']?></td>
		<td><?php echo $row['CoilYield']?></td>
		
	
		</tr>
	<?php } ?>
	
	</tbody>
	</table>
		 
		 
    </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>