<html>
<head>
<script src="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.css" rel="stylesheet">
<link rel="stylesheet" href="scripts/bootstrap.min.css">
<script src="scripts/jquery-3.2.1.slim.min.js" ></script>
<script src="scripts/popper.min.js"></script>
<script src="scripts/bootstrap.min.js"></script>
<script src="scripts/jquery.min.js"></script>
</head>

<style>
  #test-table{
    max-width: 2480px;
    width:100%;
  }
  #test-table td{
    width: auto;
    overflow: hidden;
    word-wrap: break-word;
  }
  #table{
	display:none;
  }

</style>
<body>

<?php include("navmenu.php"); ?>
<?php include("modalcoils.php"); ?>
<?php include("modalbended.php"); ?>
<?php include("modalmisc.php"); ?>
<div id="example"></div>
<div id="table">
<table id="test-table" >

</table>
</div>
<button onclick="calculate();">Calculate</button>
<button onclick="print();">Print</button>
<button data-toggle="modal" data-target="#coilinventorymodel">Coils Inventory</button>
<button data-toggle="modal" data-target="#bendedinventorymodal">Bended Inventory</button>
<button data-toggle="modal" data-target="#miscinventorymodal">Misc Inventory</button>
<script>


const data = [
 ['NAME:', '', '', '', '', '', '', '', '', '', '', 'DATE:', '', '', '', '', '','',''],
  ['ADDRESS:', '', '', '', '', '', '', '', '', '', '', 'S.R.', '', '', '', '', '','',''],
  ['TEL#:', '', '', '', '', '', '', '', '', '', '', 'REFERENCE:', '', '', '', '', '','',''],
  ['PROJECT:', '', '', '', '', '', '', '', '', '', '', 'S.Q. NO:', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', 'P.O. NO:', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
['QTY', 'UNIT', 'DESCRIPTION', '', '', '', '', '', '', '', '', 'UNIT PRICE', 'TOTAL', 'LMS', 'TONNAGE','YIELD', 'CATEGORY', 'ITEM NO.','COLOR'],
  ['', 'PCS', '', '', 'mm', 'x', '', 'mm', 'x', '', 'mm', '', '', '', '','', '', '',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','',''],
  ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '','','']
 
];

const container = document.getElementById('example');
const hot = new Handsontable(container, {
  data: data,
colWidths: [40,80,150,55,35,15,40,35,15,45,35,100,80,50,85,60,115,100,150],
  formulas: true,
  licenseKey: 'non-commercial-and-evaluation',
  mergeCells:true,
  wordwrap:false,
  colHeaders: true,
  rowHeaders: true,
  mergeCells:[{row:8,col:2,rowspan:1,colspan:9},
	  {row:0,col:0,rowspan:1,colspan:2},
	  {row:1,col:0,rowspan:1,colspan:2},
	  {row:2,col:0,rowspan:1,colspan:2},
	  {row:3,col:0,rowspan:1,colspan:2},
	  {row:6,col:0,rowspan:1,colspan:13}],
  cell:[{row: 8, col: 2, className: "htCenter"}] ,
  columns:[
  {type: 'numeric'},
  {
	   type: 'dropdown',
      source: ['PCS', 'BOX', 'LMS']
  },
  {
	  type: 'dropdown',
      source: ['TurinRib 1220', 'TurinCrv 1220', 'Corrugated', 'Genova Tile', 'Prime Cld Ord', 'Prime Cld Prf', 'Prime Deck', 'Plain Sheet', 'Ridge Cap', 'Ridge Roll', 'L-Box Gutter', 'L-Box End Flsg', 'Capping Flsg', 'Capping', 'Inside Gutter', 'Box End Flsg', 'Box Gutter', 'Valley Gutter', 'Wall End Flsg', 'Wall Flsg', 'Spnsh Gutter', 'SpnshEnd Flsg', 'Color:Red Dragon', 'Color:Bloody Red', 'Color:Cozy Blue', 'Color:Charcoal Gray', 'Color:Choco Brown', 'Color:Foam Green', 'Color:Jade Green', 'Color:Terracotta', 'Color:Pearl White', 'Color:Ivory, Color:G.I.', 'Color:B.I.', 'Color:S/S MATT 304', 'Color:S/S MIRROR 304']
  },
  {type: 'dropdown',
      source: ['0.35', '0.40', '0.50','0.60','1.00']},
  {},
  {},
   {type: 'numeric',
     numericFormat: {
        pattern: '0,0'
      }},
  {},
  {},
   {type: 'numeric',
     numericFormat: {
        pattern: '0,0'
      }},
  {},
  {type: 'numeric',
   numericFormat: {
        pattern: '0,0.00'
      }},
  {type: 'numeric',
  numericFormat: {
        pattern: '0,0.00'
      }},
  {type: 'numeric'},
  {type: 'numeric',
  numericFormat: {
        pattern: '0,0.0000'
      }},
  {type: 'numeric'},
  {
	   type: 'dropdown',
      source: ['Roofing', 'Bended', 'BendedStock', 'Misc','Color','Note']
  },
   {},
   {
	   type: 'dropdown',
      source: ['Red Dragon','Bloody Red','Cozy Blue','Charcoal Gray','Choco Brown','Foam Green','Jade Green','Terracotta','Pearl White','Ivory','G.I.','B.I.','S/S MATT 304','S/S MIRROR 304']
  },
  ],
  cells: function(row, col, prop) {
      var cellProperties = {};

      if (row === 8) {
        cellProperties.readOnly = true;
      }
	  else if(row < 8 && col < 20 && row != 6){
		  cellProperties.type = 'text';
	  }
	  else if (row === 6 && col === 0) {
        cellProperties.type = 'dropdown';
		cellProperties.source = ['Color:Red Dragon', 'Color:Bloody Red', 'Color:Cozy Blue', 'Color:Charcoal Gray', 'Color:Choco Brown', 'Color:Foam Green', 'Color:Jade Green', 'Color:Terracotta', 'Color:Pearl White', 'Color:Ivory, Color:G.I.', 'Color:B.I.', 'Color:S/S MATT 304', 'Color:S/S MIRROR 304','Hardware Accessories'];
		cellProperties.className = "htCenter";
      }

      return cellProperties;
    }
  
});



function calculate(){
	
	for(var i=9;i<=23;i++){
		var name = hot.getDataAtCell(i,2);
		var qty = hot.getDataAtCell(i,0);
		var price = hot.getDataAtCell(i,11);
		var length = hot.getDataAtCell(i,9);
		var width = hot.getDataAtCell(i,6);
		var Yield = hot.getDataAtCell(i,15);
		var category = hot.getDataAtCell(i,16);
		
		if(price == ''){
			
	}
	else{ 
	
	if(category == "Roofing" || category == "Bended" ||category == "BendedStock"){
			var lms = qty*length/1000;
			var total = qty * price;
			var multiplier = 1220/width;
			var multiplier2 = parseFloat(multiplier.toFixed(2));
		if(multiplier2<1.5){
			var tonnage = lms/Yield;
		}
		else if(multiplier2>4){
			var tonnage = lms/Yield/4;
			
		}else{
			var tonnage = (lms/Yield)/multiplier2;
		}
			
			hot.setDataAtCell(i,12, total);
			hot.setDataAtCell(i,13, lms);
			hot.setDataAtCell(i,14, tonnage);
			
			
		}
		else if(category == "Misc"){
			var total = qty * price;
			hot.setDataAtCell(i,12, total);
		}
		
		
	}
	}
	
}


function print(){
	
    var mywindow = window.open('', 'PRINT', 'height=400,width=600');

    mywindow.document.write('<html><head><title>' + document.title  + '</title><link href="https://cdn.jsdelivr.net/npm/handsontable/dist/handsontable.full.min.css" rel="stylesheet"><style>#test-table{ max-width: 2480px;width:100%;}#test-table td{width: auto;overflow: hidden; word-wrap: break-word;}</style>');
    mywindow.document.write('</head><body >');
    mywindow.document.write('<h1>' + document.title  + '</h1>');
    mywindow.document.write(document.getElementById("table").innerHTML);
    mywindow.document.write('</body></html>');

 
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
  

    return true;

	
}

var t = "";
for (var i = 0; i < data.length; i++){
      var tr = "<tr>";
      tr += "<td>"+data[i][0]+"</td>";
      tr += "<td>"+data[i][1]+"</td>";
	  if(i== 0){
		  tr += "<td colspan = 9><center>"+data[i][2]+"</center></td>";
	  }
	  else{
      tr += "<td>"+data[i][2]+"</td>";
      tr += "<td>"+data[i][3]+"</td>";
	    tr += "<td>"+data[i][4]+"</td>";
      tr += "<td>"+data[i][5]+"</td>";
      tr += "<td>"+data[i][6]+"</td>";
      tr += "<td>"+data[i][7]+"</td>";
	    tr += "<td>"+data[i][8]+"</td>";
      tr += "<td>"+data[i][9]+"</td>";
tr += "<td>"+data[i][10]+"</td>";}
      tr += "<td align='right'>"+data[i][11]+"</td>";
	   tr += "<td align='right'>"+data[i][12]+"</td>";

      tr += "</tr>";
      t += tr;
}
document.getElementById("test-table").innerHTML += t;
</script>

