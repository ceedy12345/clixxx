<?php
$db = mysqli_connect('192.168.1.100','onesteel','onesteel','onesteel');

?>