<?php
header("location:testpage.php");
exit();

?>