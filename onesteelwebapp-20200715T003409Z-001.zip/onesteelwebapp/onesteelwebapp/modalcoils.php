<?php
require_once("serverconfig.php");

$results = mysqli_query($db, 'SELECT * FROM inventorylist');	

?>
<style>
.modal{
	text-align:center
	
}
.modal-dialog{
	text-align:left;
	max-width: 100%;
	width: auto !important;
	display: inline-block;
	
}





</style>

 <div class="modal fade" id="coilinventorymodel" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
		<h4 class="modal-title">Coil Inventory</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          <div class="container">
		 	<table class="table" style="overflow:auto;">
	
	 <thead>
    <tr>
	 <th scope="col">CoilNo</th>
      <th scope="col">Color</th>
	  <th scope="col">Remarks</th>
	  <th scope="col">Yield</th>
      <th scope="col">Thickness</th>
	  <th scope="col">Width</th>
	  <th scope="col">Beg. Length</th>
	  <th scope="col">Rem. Length</th>
	  <th scope="col">Beg. Weight</th>
	  <th scope="col">Rem. Weight</th>

	
    </tr>
	<tbody>
	<?php
	while($row  = mysqli_fetch_array($results)){ ?>
		<tr>
		<td><?php echo $row['Coilno']?></td>
		<td><?php echo $row['Color']?></td>
		<td><?php echo $row['Remarks']?></td>
		<td><?php echo $row['Yield']?></td>
		<td><?php echo $row['Thickness']?></td>
		<td><?php echo $row['Width']?></td>
		<td><?php echo $row['BeginningLengthM']?></td>
		<td><?php echo $row['RemainingLengthM']?></td>
		<td><?php echo $row['BeginningWeightTon']?></td>
		<td><?php echo $row['ActualWeightTon']?></td>
	
		</tr>
	<?php } ?>
	
	</tbody>
	</table>
		 
		 
		 
    </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>