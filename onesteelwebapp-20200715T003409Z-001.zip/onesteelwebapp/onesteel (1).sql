-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2020 at 07:31 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onesteel`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitylist`
--

CREATE TABLE `activitylist` (
  `id` int(255) NOT NULL,
  `Activity` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bendedlist`
--

CREATE TABLE `bendedlist` (
  `id` int(255) NOT NULL,
  `date` date DEFAULT NULL,
  `itemName` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `thickness` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `length` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `CoilWidth` varchar(255) DEFAULT NULL,
  `CoilYield` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bendedlist`
--

INSERT INTO `bendedlist` (`id`, `date`, `itemName`, `quantity`, `thickness`, `width`, `length`, `category`, `Color`, `CoilWidth`, `CoilYield`) VALUES
(12, '2020-01-04', 'Spanish Gutter 18\"', '107', '0.40', '457', '2440', 'bendedStock', 'Cozy Blue', '915', '373.77188'),
(13, '2020-01-04', 'Valley Gutter 18\"', '15', '0.40', '457', '2440', 'bendedStock', 'Cozy Blue', '915', '373.77188'),
(14, '2020-01-04', 'Spanish End Flsg 18\"', '25', '0.40', '457', '2440', 'bendedStock', 'Cozy Blue', '915', '373.77188'),
(15, '2020-01-04', 'Ridge Roll 18\"', '107', '0.40', '457', '2440', 'bendedStock', 'Cozy Blue', '915', '373.77188'),
(16, '2020-01-04', 'Ridge Cap', '26', '0.40', '457', '2600', 'bendedStock', 'Cozy Blue', '915', '373.77188'),
(20, '2020-01-04', 'Spanish Gutter 16\"', '83', '0.40', '407', '2440', 'bendedStock', 'Cozy Blue', '1220', '283.23438'),
(21, '2020-01-04', 'Valley Gutter 16\"', '37', '0.40', '407', '2440', 'bendedStock', 'Cozy Blue', '1220', '283.23438'),
(22, '2020-01-04', 'Spanish End Flsg 16\"', '15', '0.40', '407', '2440', 'bendedStock', 'Cozy Blue', '1220', '283.23438'),
(23, '2020-01-04', 'Ridge Roll 16\"', '86', '0.40', '407', '2440', 'bendedStock', 'Cozy Blue', '1220', '283.23438'),
(25, '2020-01-04', 'Ridge Cap', '46', '0.40', '457', '2440', 'bendedStock', 'Red Dragon', '915', '355.32333'),
(26, '2020-01-04', 'Ridge Cap', '40', '0.40', '457', '2440', 'bendedStock', 'Bloody Red', '915', '380.90'),
(27, '2020-01-04', 'Ridge Cap', '708', '0.40', '457', '2440', 'bendedStock', 'Terracotta', '915', '366.53183'),
(29, '2019-11-04', 'Ridge Cap', '113', '0.40', '457', '2440', 'bendedStock', 'Jade Green', '915', '366.53183'),
(30, '2020-01-04', 'Ridge Cap ', '9', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '915', '368.56436'),
(31, '2019-09-04', 'Ridge Cap', '45.0', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '1220', '0'),
(32, '2020-01-04', 'Spanish Gutter 18\"', '18', '0.40', '457', '2440', 'bendedStock', 'Terracotta', '915', '361.80307'),
(33, '2019-11-04', 'Spanish End Flsg 18\"', '14', '0.40', '457', '2440', 'bendedStock', 'Terracotta', '915', '361.80307'),
(34, '2020-01-04', 'Ridge Roll 18\"', '92', '0.40', '457', '2440', 'bendedStock', 'Terracotta', '915', '361.80307'),
(35, '2019-11-04', 'Valley Gutter 18\"', '17', '0.40', '457', '2440', 'bendedStock', 'Terracotta', '915', '361.80307'),
(36, '2020-01-04', 'Spanish Gutter 16\"', '25', '0.40', '407', '2440', 'bendedStock', 'Terracotta', '1220', '278.40'),
(37, '2020-01-04', 'Spanish End Flsg 16\"', '30', '0.40', '407', '2440', 'bendedStock', 'Terracotta', '1220', '278.40'),
(38, '2020-01-04', 'Ridge Roll 16\"', '13', '0.40', '407', '2440', 'bendedStock', 'Terracotta', '1220', '278.40'),
(39, '2020-01-04', 'Valley Gutter 16\"', '29', '0.40', '407', '2440', 'bendedStock', 'Terracotta', '1220', '278.40'),
(40, '2020-01-04', 'End Moulding ', '49', '0.40', '152', '2440', 'bendedStock', 'Pearl White', '1220', '274.47092'),
(41, '2020-01-04', 'End Moulding ', '47', '0.40', '152', '2440', 'bendedStock', 'Ivory', '1220', '284.8865'),
(42, '2020-01-04', 'End Moulding ', '50', '0.50', '152', '2440', 'bendedStock', 'Pearl White', '1220', '213.2228'),
(43, '2020-01-04', 'End Moulding ', '34', '0.50', '152', '2440', 'bendedStock', 'Ivory', '1220', '217.41133'),
(44, '2020-01-04', 'Spanish Gutter 16\"', '65', '0.40', '407', '2440', 'bendedStock', 'Jade Green', '1220', '282.0386'),
(46, '2020-01-04', 'Spanish End Flsg 16\"', '30', '0.40', '407', '2440', 'bendedStock', 'Jade Green', '1220', '282.0386'),
(47, '2020-01-04', 'Ridge Roll 16\"', '65', '0.40', '407', '2440', 'bendedStock', 'Jade Green', '1220', '282.0386'),
(48, '2019-11-04', 'Valley Gutter 16\"', '12', '0.40', '407', '2440', 'bendedStock', 'Jade Green', '1220', '282.0386'),
(53, '2020-01-04', 'Spanish Gutter 16\"', '102', '0.40', '407', '2440', 'bendedStock', 'Red Dragon', '1220', '289.92395'),
(54, '2020-01-04', 'Spanish End Flashing 16\"', '29', '0.40', '407', '2440', 'bendedStock', 'Red Dragon', '1220', '289.92395'),
(55, '2020-01-04', 'Ridge Roll 16\"', '48', '0.40', '407', '2440', 'bendedStock', 'Red Dragon', '1220', '289.92395'),
(56, '2020-01-04', 'Valley Gutter 16\"', '30', '0.40', '407', '2440', 'bendedStock', 'Red Dragon', '1220', '289.92395'),
(57, '2020-01-04', 'Spanish Gutter 16\"', '27', '0.40', '407', '2440', 'bendedStock', 'Bloody Red', '1220', '309.97986'),
(58, '2020-01-04', 'Spanish End Flsg 16\"', '26', '0.40', '407', '2440', 'bendedStock', 'Bloody Red', '1220', '309.97986'),
(59, '2020-01-04', 'Ridge Roll 16\"', '22', '0.40', '407', '2440', 'bendedStock', 'Bloody Red', '1220', '309.97986'),
(60, '2019-11-04', 'Valley Gutter 16\"', '33', '0.40', '407', '2440', 'bendedStock', 'Bloody Red', '1220', '309.97986'),
(61, '2020-01-04', 'Spanish Gutter 16\"', '35', '0.40', '407', '2440', 'bendedStock', 'Choco Brown', '1220', '287.14105'),
(62, '2020-01-04', 'Spanish End Flsg 16\"', '35', '0.40', '407', '2440', 'bendedStock', 'Choco Brown', '1220', '287.14105'),
(63, '2020-01-04', 'Ridge Roll  16\"', '42', '0.40', '407', '2440', 'bendedStock', 'Choco Brown', '1220', '287.14105'),
(64, '2020-01-04', 'Valley Gutter 16\"', '28', '0.40', '407', '2440', 'bendedStock', 'Choco Brown', '1220', '287.14105'),
(65, '2020-01-04', 'Spanish Gutter 18\"', '84', '0.40', '457', '2440', 'bendedStock', 'Jade Green', '915', '366.53183'),
(66, '2020-01-04', 'Spanish End Flsg 18\"', '23', '0.40', '457', '2440', 'bendedStock', 'Jade Green', '1220', '281.28'),
(67, '2020-01-04', 'Ridge Roll 18\"', '72', '0.40', '457', '2440', 'bendedStock', 'Jade Green', '915', '366.53183'),
(68, '2020-01-04', 'Valley Gutter 18\"', '18', '0.40', '457', '2440', 'bendedStock', 'Jade Green', '915', '366.53183'),
(76, '2020-01-04', 'Spanish Gutter 18\"', '107', '0.40', '457', '2440', 'bendedStock', 'Red Dragon', '915', '355.32333'),
(77, '2020-01-04', 'Spanish End Flashing 18\"', '34', '0.40', '457', '2440', 'bendedStock', 'Red Dragon', '915', '355.32333'),
(78, '2020-01-04', 'Ridge Roll  18\"', '30', '0.40', '457', '2440', 'bendedStock', 'Red Dragon', '915', '355.32333'),
(79, '2019-11-04', 'Valley Gutter 18\"', '15', '0.40', '457', '2440', 'bendedStock', 'Red Dragon', '915', '355.32333'),
(80, '2020-01-04', 'Spanish Gutter 18\"', '61', '0.40', '457', '2440', 'bendedStock', 'Bloody Red', '915', '380.90'),
(81, '2020-01-04', 'Spanish End Flsg 18\"', '27', '0.40', '457', '2440', 'bendedStock', 'Bloody Red', '915', '380.90'),
(82, '2020-01-04', 'Ridge Roll  18\"', '73', '0.40', '457', '2440', 'bendedStock', 'Bloody Red', '915', '380.90'),
(83, '2019-11-04', 'Valley Gutter 18\"', '34', '0.40', '457', '2440', 'bendedStock', 'Bloody Red', '915', '380.90'),
(84, '2020-01-04', 'Spanish Gutter 18\"', '36', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '915', '368.56436'),
(85, '2020-01-04', 'Spanish End Flsg 18\"', '14', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '915', '368.56436'),
(86, '2020-01-04', 'Ridge Roll  18\"', '110', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '915', '368.56436'),
(87, '2020-01-04', 'Valley Gutter 18\"', '47', '0.40', '457', '2440', 'bendedStock', 'Choco Brown', '915', '368.56436');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(255) NOT NULL,
  `Fullname` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `TelNo` varchar(255) NOT NULL,
  `PriceCategory` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `Fullname`, `Address`, `TelNo`, `PriceCategory`) VALUES
(6, 'Obet Pugay', 'Lucena City', '09207927159', 'End User'),
(7, 'St. Gabriel Glass & Aluminum', 'Lucena City', '', 'Contractor'),
(9, 'Lucena Hope Academy', 'Lucena City', '', 'Contractor'),
(10, 'Lucena Marktown Inc.', 'Gomes Ext., Red-V, Lucena City', '3730915/7104628', 'Hardware'),
(11, 'Don zalvo', 'Lucena city', '', 'End User'),
(13, 'cesar iglesia', 'guinyangan, quezon', '09412241808', 'End User'),
(14, 'mike miguel', 'lucena city', '', 'End User'),
(15, 'JAAP General Merchandise', 'Paete st., Rosario village', '09088670802', 'End User'),
(16, 'Bong Cadelina', 'Paete St., Rosario village', '09088670802', 'End User'),
(17, 'Eduardo Naynes', 'Tayabas city', '09486993724', 'End User'),
(18, 'Eng\'r Homer Gonzales', 'Polilio, Quezon', '', 'Contractor'),
(19, 'Atty. Glenn tan', 'lucena city', '', 'End User'),
(20, 'Hanson Ship Building', '09338568725', '', 'Hardware'),
(21, 'Marissa Flores', 'quezon, quezon', '09075365905', 'End User'),
(22, 'Paul Callanta', 'ibabang Dupay, lucena city', '09108794241', 'End User'),
(23, 'lucena A&G', '', '3733052', 'End User'),
(24, 'Danny Macaraig', 'lucena city', '', 'End User'),
(25, 'Elmer Maaliw', 'Gulang2x', '09228125087', 'End User'),
(26, 'Robinsam steel', 'lucena city', '', 'Hardware-A'),
(27, 'Eng\'r Arvin Ayala', 'pagbilao, quezon', '', 'End User'),
(28, 'Maranan Hardware', 'guinayangan, Quezon', '', 'Hardware-A'),
(29, 'EDG', 'sta cruz, m\'dque', '', 'Hardware'),
(30, 'Genesis Ranillo ', 'Mayao Silangan Lucena City', '09225948210', 'End User'),
(31, 'Romel Gagan', 'Lucena City', '09178048346', 'End User'),
(32, 'Nelson Lim', 'Marinduque ', '09186560030', 'End User'),
(33, 'Christian Morales ', 'Lucena City ', '09260742356', 'End User'),
(34, '3DK STEEL MARKETING', 'Red- V, Lucena City', '', 'Hardware'),
(35, 'DANOS HARDWARE', 'Sampaloc, Quezon', '0948-3879684', 'Hardware-A'),
(36, 'Gerry P. Eleazar', 'Tayabas City', '0945-1144-476', 'End User'),
(37, 'MAJOR MARQUEZ', 'Sariaya, Quezon', '', 'End User'),
(38, 'Jayson Castillo', 'Brgy.,Talipan Pagbilao,Quezon', '09072218684', 'End User'),
(39, 'Eric Dapol', 'Lucena City', '', 'End User'),
(40, 'Lauro M. Segala', 'Lucena City', '09098469970', 'End User'),
(41, 'Arnold Villanueva', 'Ibabang Talim, Lucena City', '09109994954/ 09300130514', 'End User'),
(42, 'Michael cheong', 'intertown, pagbilao', '', 'End User'),
(43, 'ariel lopez', '', '', 'End User'),
(44, 'MCST home care building', 'tayabas city', '', 'End User'),
(45, 'wisebuy hardware', '', '', 'End User'),
(46, 'Roman Zarsuelo', 'brgy Parang, Pagbilao', '', 'End User'),
(47, 'bong rosales', '', '', 'Contractor'),
(48, 'New Mabulay Hardware', 'lucena city', '7973570', 'Hardware-A'),
(49, 'Romeo Alfabete', 'lucena city', '', 'End User'),
(50, 'Edel Ramos', 'lucena city', '09129653781', 'End User'),
(51, 'John Almonte', 'Gen luna, quezon', '', 'Hardware-A'),
(52, 'Wennie Barnuevo', 'Perez, Quezon', '09124298756', 'End User'),
(53, 'Minda Restar', 'lucena city', '09178779190', 'End User'),
(54, 'Nick Briones', 'Mulanay, Quezon', '09085853960', 'End User'),
(55, 'Etoy Acaso', 'Dalahican, Lucena City', '', 'End User'),
(56, 'Lucena Central Lumber And Hardware', 'Lucena City', '', 'End User'),
(57, 'KOOP NAMAN MULTIPURPOSE', 'Lucena City', '', 'End User'),
(58, 'Engr. Narciso Alcantara', 'Pagbilao, Quezon', '09053229565', 'Contractor'),
(59, 'AR. JEROME VALBUENA', 'Lucena City', '', 'Hardware-B'),
(60, 'Tony Alegria', 'Tagkawayan, Quezon', '0946-577-2368', 'End User'),
(61, 'MARIO SANTE', 'Lucena City', '0938-609-8789', 'End User'),
(62, 'FELIX RACELIS', 'Lucban,Quezon', '0910-453-4447', 'End User'),
(63, 'MARIAL CAPIO', 'Mauban, Quezon', '', 'End User'),
(64, 'BOMEL CONSTRUCTION', 'Lucena City', '(042) 710-9632', 'Hardware-B'),
(65, 'QUALITY CERAMICS INC. c/o MARILYN/ AR. VLAD', 'Gomez Ext. Red-V, Lucena City', '(042) 373-5798', 'Hardware'),
(66, 'ANGELITO BOYET ZURBANO', 'Sto. Rosario Brgy. 4 Lucena City', '0938-582-7323', 'End User'),
(67, 'JANTIN ENTERPRISES', 'Cotta, Lucena City', '0922-804-9314', 'Hardware-B'),
(68, 'ULYSSES ORFANO', 'Lucena City', '', 'End User'),
(69, 'MICHAEL', 'TOLENTINO', '0915-1338-631', 'End User'),
(70, 'ENGR. LYDIA FALLER', 'Lucena City', '', 'End User'),
(71, 'VINCENT MONTEROLA', 'Brgy. Del Carmen Pagbilao,Quezon', '0910-963-6700', 'Hardware'),
(72, '3DK STEEL MARKETING', 'Lucena City', '', 'Hardware'),
(73, 'RON FALLER', 'Lucena City', '', 'End User'),
(74, 'RON FALLER', 'Lucena City', '', 'End User'),
(75, 'VERON CANTOS', 'Lucena City', '', 'End User'),
(76, 'FROILAN ABAD', 'TAYABAS CITY', '09465794552', 'End User'),
(77, 'RM ROSALES', 'Lucena City', '', 'End User'),
(78, 'MARISSA LINIAL', 'Mauban, Quezon', '0929-666-3683', 'End User'),
(79, 'ABEGAIL MANDRIQUE', 'Mauban, Quezon', '0956-948-7388', 'End User'),
(80, 'RON FALLER', 'Lucena City', '', 'End User'),
(81, 'ROMULO ARANILLA', 'Mayao Parada Lucena City', '', 'End User'),
(82, 'JOSEPH REAVELES', 'Sariaya, Quezon', '', 'End User'),
(83, 'DOMINGO DAPOL', 'Lucena City', '', 'End User'),
(84, 'GERARDO IGNACIO', 'Lucena City', '0948-562-0647', 'End User'),
(85, 'MARANAN HARDWARE', 'Guinyangan, Quezon', '', 'End User'),
(86, 'MARANA HARDWARE', 'Guinayangan, Quezon', '', 'Hardware-A'),
(87, 'RODELIO VILLARAMA', 'Atimonan, Quezon', '0910-960-7978', 'End User'),
(88, 'MIC- GIE ENTERPRISE', 'Eco-Tourism Road Bignay II Sariaya, Quezon', '0947-994-9176', 'Hardware-A'),
(89, 'NANCY VINAS', 'Lucena City', '0948-2870-646', 'End User'),
(90, 'CARMEL OF SAINT JOSEPH', 'Lucena City', '0949-3287-970', 'End User'),
(91, 'ROWEN PEDREZUELA', 'Lucena City', '0930-1147-599', 'End User'),
(92, 'AR. SID VILLASANTA', 'Bacungan Lopez, Quezon', '', 'Hardware-A'),
(93, 'TOP GROSSER HARDWARE', 'Maharlika H-way Alupaye, Pagbilao,Quezon', '', 'Hardware-A'),
(94, 'ROWEN PEDREZUELA', 'Lucena City', '0930-114-7599', 'End User'),
(95, 'ALABAT TRADING', 'Alabat, Quezon', '', 'Hardware-B'),
(96, 'MARICEL CABALAG', 'Tagkawayan,Quezon', '', 'End User'),
(97, 'ARIES LUBIANO', 'Tayabas, City', '', 'End User'),
(98, 'ANTOLIN GOLPEO', 'Guinyangan, Quezon', '0966-6092-816', 'End User'),
(99, 'RUBEN RENIGADO', 'Lucena City', '0908-4828-900', 'End User'),
(100, 'AIMAR VIAJE', 'Mauban,Quezon', '0920-5678-052', 'End User'),
(101, 'JUN ABCEDE', 'Lucena City', '', 'End User'),
(102, 'DELY RAMOS', 'Lucena City', '', 'End User'),
(103, 'JOHN RONALD HERNANDEZ', 'Lucena City', '0917-3546-984', 'End User'),
(104, 'GRAND URMATA c/o AR. BELTRAN', 'Marinduque', '', 'Hardware-B'),
(105, 'CARMEL OF SAINT JOSEPH', 'Lucena City', '0949-3287-970', 'End User'),
(106, 'NANCY VIÑAS', 'Lucena City', '0948-2870-646', 'End User'),
(107, 'RODELIO VILLARAMA', 'Atimonan,Quezon', '0910-960-7978', 'End User'),
(108, 'CHAR REAL ESTATE DEALER c/o ELVIRA A. SALES', 'Brgy.Bigaan Guisguis Sariaya,Quezon', '0925-511-9433', 'Hardware-B'),
(109, 'RAUL SIMBAJON', 'Lucena City', '', 'End User'),
(110, 'QUALITY CERAMICS INC. c/o MYRA S.', 'Gomez Ext. Red-V, Lucena City', '042-373-5798', 'Hardware'),
(111, 'BEN MONTEVERDE', 'Lucena City', '', 'End User'),
(112, 'UNI-A CONSTRUCTION', 'Lucena City', '', 'Hardware-A'),
(113, 'WARREN PRINCIPE', 'Lucena City', '0907-134-6019', 'End User'),
(114, 'DIONISIO AQUINO', 'Lucena City', '', 'End User'),
(115, 'MAXIMUM GAS CORP.', 'Lucena City', '042-660-6889', 'Hardware-B'),
(116, 'BENSON TAN', 'Lucena City', '', 'Hardware-A'),
(117, 'JANETH UNGSOD', 'Lucena City', '', 'End User'),
(118, 'M.EDG c/o MICHEL VIZARRA', 'Marinduque', '', 'Hardware'),
(119, 'WISEBUY HARDWARE', 'Red- V Lucena City', '', 'Hardware-A'),
(120, 'RANDY REYES', 'Lucena City', '', 'Hardware-B'),
(121, 'AR. MICHAEL PUACHE', 'Lucena City', '', 'End User'),
(122, 'JOSEPH REAVELES', 'Sariaya, Quezon', '', 'End User'),
(123, 'PRIORITY TRADING', 'Lucena City', '', 'End User'),
(124, 'RAMON PUACHE', 'Unisan,Quezon', '', 'Hardware-A'),
(125, 'ALABAT TRADING', 'Alabat , Quezon', '', 'Hardware-A'),
(126, 'JOSE FERNANDEZ', 'Guinyangan,Quezon', '0918-1756-2034', 'End User'),
(127, 'LLIANTERO', 'Lucena City', '', 'End User'),
(128, 'NICK DEL MUNDO', 'Lucena City', '', 'End User'),
(129, 'JOSEPH REAVELES', 'Lucena City', '', 'Contractor'),
(130, 'ROBERTO MARANAN', 'Lucena City', '', 'End User'),
(131, 'M.EDG c/o TOPER MATIENZO', 'Marinduque', '', 'Hardware'),
(132, 'MAR GANDIA', 'Mauban, Quezon', '0928-7480-118', 'End User'),
(133, 'WISE BUY', 'Lucena City', '', 'Hardware-A'),
(134, 'FERDINAND BOLFANE', 'Tayabas City', '0946-505-9474', 'End User'),
(135, 'ARIES TOLETE', 'Lucena City', '0922-4047-980', 'End User'),
(136, 'NANGKA ELEM. SCHOOL', 'Marinque', '0946-173-7678', 'End User'),
(137, 'EVA QUINSANOS', 'Tayabas City', '', 'End User'),
(138, 'ROLAND CARABALLO', 'Brgy. Mayao Silangan Lucena City ', '0910-766-1543', 'End User'),
(139, 'GERALDINE ALPAY', 'Lucena City', '', 'End User'),
(140, 'GLENN PARCAREY', 'Lucena City', '', 'End User'),
(141, 'REYNAN MOLBOG', 'Boac, Marinduque', '0999-458-7724', 'End User'),
(142, 'MAR JOSEPH B. ELPA', 'Lucban quezon', '0999-913-7587', 'End User'),
(143, 'MIKI MART ', 'Lucena City ', '', 'End User'),
(144, 'PAUL LAVAREZ ', 'Lucena City ', '', 'End User'),
(145, 'RM ROSALES', 'Lucena City', '', 'End User'),
(146, 'DANILO PADUA', 'Lucena City', '', 'End User'),
(147, 'SALLY PORTO', 'Lucena City ', '0956-0132-2424', 'End User'),
(148, 'ZALDY MENDOZA', 'Lucena City', '0938-557-6722', 'End User'),
(149, 'DANNY MACARAIG', 'Lucena City', '', 'Contractor'),
(150, 'ELMER MARANAN', 'Sariaya, Quezon', '', 'Contractor'),
(151, 'MAGGIE CABOTAGE', 'Domoit, Lucena City', '0927-961-4606', 'End User'),
(152, 'SALVIA OBDIANELA', 'Tayabas,Quezon', '0950-391-4843', 'End User'),
(153, 'EDMON ANDAY', 'Lucena City', '', 'End User'),
(154, 'ALICE TADIOSA', 'Lucena City', '', 'End User'),
(155, 'LORY CATAPANGAN', 'Pagbilao, Quezon', '', 'Contractor'),
(156, 'JUN HOYOHOY', 'Lucena City', '0922-4028-301', 'End User'),
(157, 'ROMY MAGHANOY', 'Mayao, Castillo Lucena City', '0909-987-6961', 'End User'),
(158, 'CHAR REAL ESTATE DEALER c/o ELVIRA SALES', 'Lucena City', '', 'Hardware-B'),
(159, 'MONTANO LLAGAS', 'AGDANGAN,QUEZON', '0948-905-3291', 'End User'),
(160, 'PIZARRA TRUCKING', 'Marinduque', '0955-300-4548', 'End User'),
(161, 'ARNEL BAUTISTA', 'Padre, Burgos', '0966-621-1312', 'End User'),
(162, 'DARYL LAURELES', 'Lucena City', '', 'End User'),
(163, 'DANNY PANGILIGAN', 'Cotta, Lucena City', '0908-479-3094', 'End User'),
(164, 'JESSON PARALIS', 'Pagbilao,Quezon', '0921-362-3724', 'End User'),
(165, 'BLISSFUL MARKETING', 'Lucena City', '', 'End User'),
(166, 'RICHARD EVANGELISTA', 'Lucena City', '0936-156-7646', 'End User'),
(167, 'NELSON UMBRETE', 'Lucena City', '', 'End User'),
(168, 'JOSEPH REAVELES', 'Lucena City', '0933-460-3758', 'Hardware-B'),
(169, 'ELVIS LIM ', '', '', 'Hardware-B'),
(170, 'UNI-A CONSTRUCTION ', '', 'LUCENA CITY ', 'Hardware-A'),
(171, 'UNI- A CONSTRUCTION', 'Lucena City', '', 'Hardware-A'),
(172, 'VINCENT MONTEROLA', 'St., Jude - Lucena City', '', 'Hardware-A'),
(173, 'LMV', 'Sariaya, Quezon', '0947-3409-899', 'End User'),
(174, 'SANDY POSTRADO', 'Lucena City', '', 'End User'),
(175, 'NANETH HERNANDEZ', 'Gumaca, Quezon', '', 'End User'),
(176, 'HENRY MORALES', 'Lucena City', '0908-3210-775', 'End User'),
(177, 'NESTOR SANTE', 'Lucena City', '0909-692-6996', 'End User'),
(178, 'ROBINSAM STEEL TRADING', 'Lucena City', '', 'Hardware-A'),
(179, 'ALLAN NIEMBRES', 'Lucena City', '09158-334-5145', 'End User'),
(180, 'RYAN TORRES', 'Lucena City', '0915-6922-680', 'End User'),
(181, 'ALDRIN ESPINOSA', 'Lucena City', '0928-154-8067', 'End User'),
(182, 'NERBERT LOPEZ', 'Citta , Grande Subd., Lucena City', '0933-852-4063', 'End User'),
(183, 'JOHNNY GALANG', 'Mulanay Quezon', '09481392946', 'End User'),
(184, 'CARLO PADERON ', 'Lucena City', '', 'End User'),
(185, 'RAUL SIMBAJON', 'Lucena City', '', 'End User'),
(186, 'ENGR. CHRISTOPHER COMIA', 'Lucena City', '', 'Hardware-B'),
(187, 'ROLLY JADER', 'Tayabas City', '0909-393-2558', 'End User'),
(188, 'CHARINA MELLA', 'Lucena City', '0947-264-4977', 'End User'),
(189, 'LIEZEL CAMPOS', 'Lucena City', '', 'End User'),
(190, 'J & TOP GRILLE INC.', 'Candelaria , Quezon', '', 'End User'),
(191, 'JOHANNA\'S CHICKEN PROCESSING CENTER', 'Domoit, Lucena City', '0915-6522-872', 'End User'),
(192, 'LUCENA MARKTOWN INC. c/o PAULA', 'Gomez Extn., Red- V, Lucena City', '(042) 373-0915/ 710-4628', 'End User'),
(193, 'M. EDG c/o Ma;am ABET', 'Marinduque', '', 'Hardware'),
(194, 'DANOS HARDWARE', 'Sampaloc, Quezon', '', 'Hardware-A'),
(195, 'ANALYN CALIBUSO', 'Lucena City', '0909-482-2564', 'End User'),
(196, 'PANG. CHOY ORIVIDA', 'St. Jude Phase 2-c , Lucena City', '0933-4060-939/0912-9111-467', 'End User'),
(197, 'DANNY GLORIA', 'Pagbilao, Quezon', '', 'Contractor'),
(198, 'ISAAC ILAGAN', 'Lucena City', '0948-204-6762', 'End User'),
(199, 'QUALITY CERAMICS INC. c/o MARLYN', 'Gomez Ext., Red-V, Lucena City', '(042) 373-5798', 'End User'),
(200, 'ENGR. NARCISO ALCANTARA', 'Lucena City', '', 'Contractor'),
(201, 'JANMING CONSTRUCTION AND SUPPLIES', 'Lucena City', '', 'End User'),
(202, 'JSP CONSTRUCTION', 'Silangang Mayao, Lucena City', '', 'Contractor'),
(203, 'LUCENA MARKTOWN INC c/o IMELDA', 'Gomez Extn., Red-V, Lucena City', '(042) 373-0915', 'End User'),
(204, 'LUCENA MARKTOWN INC. c/o LEAH', 'Gomez Extn., Red-V Lucena City', '(042) 373-0915', 'Hardware'),
(205, 'ALVIN DETOBIO', 'Talipan Pagbilao, Quezon', '0919-853-6877', 'End User'),
(206, 'LUCENA MARKTOWN c/o JULIE', 'Lucena City', '', 'Hardware'),
(207, 'QUALITY CERAMICS INC.,c/o MARLYN', 'Gomez Ext. Red-V, Lucena City', '(042) 373-5798', 'Hardware'),
(208, 'KENNETH SANTILLAN', 'Lucena City', '0933-821-5123', 'Hardware-B'),
(209, 'RAMON PUACHE', 'Unisan, Quezon', '', 'End User'),
(210, 'PIZARRA TRUCKING', 'Marinduque', '0955-300-4548', 'End User'),
(211, 'REGINA LAGUARTA', 'Silangang Mayao, Lucena City', '0949-313-1283', 'End User'),
(212, 'JENNIFER PANGANIBAN', 'Macalelon, Quezon', '0998-5496218', 'End User'),
(213, 'SONIER CAMACHO', 'Mauban, Quezon', '0938-832-4578', 'End User'),
(214, 'ENGR. MENANDRO LUCES', 'Lucena City', '0917-8326-418', 'End User'),
(215, 'BOMEL CONSTRUCTION', 'Lucena City', '(042) 710-9632', 'End User'),
(216, 'M. EDG c/o MARCELINO ROBLES', 'Marinduque', '', 'Hardware'),
(217, 'JESSIE QUINDOZA', 'Lucena City', '0906-4977-816/0947-9730-981', 'Hardware-B'),
(218, 'LUCENA MARKTOW c/o IMELDA', 'Lucena City', '', 'Hardware'),
(219, 'REY DE OCAMPO', 'Lucena City', '0942-461-5819', 'End User'),
(220, 'OBET VEJERANO', 'Isabang Lucena City', '0922-877-3537', 'End User'),
(221, 'LORIE CATAPANGAN', 'Lucena City', '', 'Contractor'),
(222, 'LUCENA CENTRAL LUMBER & HARDWARE', 'Lucena City', '', 'Hardware'),
(223, 'NEW MABULAY HARDWARE', 'Gulang 2x Lucena City', '(042)0797-3570', 'End User'),
(224, 'VIC PALMA', 'Lucena City', '0918-3869-398', 'End User'),
(225, 'MELDY ABCEDE AROJO', 'Brgy. Domoit, Lucena City', '0998-889-4627 / 0939-496-0812', 'End User'),
(226, 'GMJ LUMBER & HARDWARE c/o ELAN GO', 'Marinduque', '', 'End User'),
(227, 'FE SIA', 'Tayabas City', '0933-8129-748', 'End User'),
(228, 'RANDY AMORANTO', 'Lucena City', '0915-154-6719', 'End User'),
(229, 'JULIET ADELINO c/o LOREMER', 'Marinduque', '0946-421-4814', 'End User'),
(230, 'J.D. RAMOS BUILDERS', 'Candelaria, Quezon', '0935-888-8191', 'End User'),
(231, 'JOHANNA\'S CHICKEN CENTER', 'Domoit, Lucena City', '0915-6522-872', 'End User'),
(232, 'ALLAN DE LA VEGA', 'Lucena City', '', 'End User'),
(233, 'M. EDG c/o MR. BEJASA', 'Marinduque', '', 'Hardware'),
(234, 'M. EDG c/o ISAGANI REVILLA', 'Marinduque', '', 'End User'),
(235, 'EDWIN NAPULE', 'Market Ave., Brgy., MarketView, Lucena City', '0943-062-8354', 'End User'),
(236, 'ROY GARCIA', 'Dalahican, Lucena City', '0930-065-8740', 'End User'),
(237, 'TERESITA CATALLA', 'Pagbilao, Quezon', '', 'End User'),
(238, 'ROY GARCIA', 'Lucena City', '', 'End User'),
(239, 'MORE CONSTRUCTION c/o ENGR. SOTO', 'Marinduque', '0933-862-9042', 'Contractor'),
(240, 'YVETTE ENRILE', 'Dama De Noche St., Capistrano Subd., Lucena City', '0932-503-4640', 'End User'),
(241, 'CESAR BULAHAN', 'Lucena City', '0950-173-6048', 'End User'),
(242, 'VINCENT MONTEROLA', 'Brgy., Del Carmen Pagbilao, Quezon', '', 'Hardware-A'),
(243, 'CARLA LEJANA', 'Lucena City', '0906-008-7152/ 710-0543', 'End User'),
(244, 'WENA ROSALES', 'Lucena City', '0928-197-7318', 'End User'),
(245, 'APRIL JOY N. ENRIQUEZ', 'Purok Central Ilaya Brgy., Kan. Mayao Lucena City', '0930-121-9694', 'End User'),
(246, 'JONATHAN AZUSAN', 'Akap Villlage Little Baguio 2 Red-V Lucena City', '0912-4306264', 'End User'),
(247, 'FRANCIS CUASAY', 'Mayao, Castillo', '0942-308-4235', 'End User'),
(248, 'NIELSEN BANAGAN', 'Mauban, Quezon', '', 'End User'),
(249, 'CESAR BULAHAN', 'Lucena City', '0950-173-6048', 'End User'),
(250, 'EVELYN RAMIREZ', 'Lucena City', '0908-495-0407', 'End User'),
(251, 'JONATHAN AZUSAN', 'Akap Village, Red- V Little Baguio, Lucena City', '0912-4306-264', 'End User'),
(252, 'SANTIAGO DE LA PENA', 'Mayao Castillo, Lucena City', '0921-719-5940', 'End User'),
(253, 'MARIO ALDOVINO', 'Purok Mutya Cotta, Lucena City', '0908-499-7272', 'End User'),
(254, 'GARCIA CONSTRUCTION SUPPLIES TRADING', 'Brgy., San Isidro, Gen. Luna, Quezon', '0928-8130-446', 'End User'),
(255, 'MACARIO SIMATA', 'Lucena City', '', 'End User'),
(256, 'JSAN TRADING', 'Sariaya, Quezon', '0947-605-8044', 'End User'),
(257, 'ROLANDO ESPAÑOL', 'Pagbilao, Quezon', '0933-586-2150', 'End User'),
(258, 'BONG CADELIÑA', 'Lucena City', '', 'Contractor'),
(259, 'JOHN ALMONTE', 'Gen. Luna, Quezon', '', 'Contractor'),
(260, 'JAY ESPEDIDO', 'Lucena City', '0920-967-0879', 'End User'),
(261, 'THELMA OBUT', 'Gulang 2x Lucena City', '0920-2420-935', 'End User'),
(262, 'LUCENA MARKTOWN c/o PAULA', 'Gomez Extn., Red-V Lucena City', '(042) 373-0915/ 710-4628', 'Hardware'),
(263, 'JOHANNA\'S CHICKEN PROCESSING CENTER', 'Lagalag, Tiaong Quezon', '0915-6522-872', 'Hardware-A'),
(264, 'ROMULO MATIBAG', 'Purok Rosal Silangang Mayao Lucena City', '0908-664-4984', 'End User'),
(265, 'WILLIAM GARCIA', 'Mayao Castillo,Lucena City', '0945-453-3545', 'End User'),
(266, 'MORE CONSTRUCTION c/o ENGR.SOTO', 'Marinduque', '0933-862-9042', 'Hardware-B'),
(267, 'EDWIN CANTOS', 'Lucena City', '0910-9798-288', 'End User'),
(268, 'ARIAN M. POSTRADO', 'Torrijos, Marinduque', '0947-581-6278', 'End User'),
(269, 'EDWIN CANTOS', 'Lucena City', '0910-9798-288', 'End User'),
(270, 'CESAR GUEVARRA', 'Lucena City', '0912-911-1467', 'End User'),
(271, 'SHIELA NARVAEZ', 'Lucena City', '', 'End User'),
(272, 'PY LACORTE', 'Lucena City', '', 'End User'),
(273, 'NELSON J. LIM', 'Marinduque', '0918-656-003/0907-901-0465', 'End User'),
(274, 'EDZEL CABRERA', 'Lucena City', '0939-761-1467', 'End User'),
(275, 'LUCENA MARKTOWN INC. c/o ARLENE', 'Gomez Extn.,Red-V,Lucena City', '(042) 373-0915/ 710-4628', 'Hardware'),
(276, 'LUCENA MARKTOWN INC. c/o ARLENE', 'Gomez Extn., Red-V, Lucena City', '(042) 373-0915', 'Hardware'),
(277, 'M.EDG c/o EDDIE VILLARUEL', 'Marinduque', '', 'Hardware'),
(278, 'M.EDG c/o MARIO EOCHA', 'Marinduque', '', 'Hardware'),
(279, 'M. EDG c/o MAX RENIEDO', 'Marinduque', '', 'Hardware'),
(280, 'M.EDG c/o ISAGANI REVILLA', 'Marinduque', '', 'Hardware'),
(281, 'JANE CUBE', '107 Luisiana, Laguna', '0928-6331-599', 'End User'),
(282, 'M.EDG c/o MONARK', 'Marinduque', '', 'Hardware'),
(283, 'MERLE LEYOLA', 'Isabang ,Tayabas', '0995- 7961-764', 'End User'),
(284, 'ARNOLD RECIO', 'Lucena City', '0929-477-7487', 'End User'),
(285, 'JERRY SIMOGAN', 'Talipan , Pagbilao, Quezon', '', 'End User'),
(286, 'M.EDG c/o MARCELINO ROBLES', 'Marinduque', '', 'Hardware'),
(287, 'IRENEO PORTES', 'Agdangan, Quezon', '', 'End User'),
(288, 'UNI-A CONSTRUCTION c/o LIZA CRISTOBAL', 'Lucena City', '', 'End User'),
(289, 'ARIES SALIMO', 'Lucena City', '--', 'End User'),
(290, 'LUCENA CENTRAL LUMBER & HARDWARE', 'Lucena City', '', 'Hardware'),
(291, 'ROBERT VELASCO', 'polillo, Quezon', '', 'End User'),
(292, 'DEMALARAN CONSTRUCTION', 'Lucena City', '0925-452-2215', 'End User'),
(293, 'RONALD DIONIDO', 'Tagkawayan, Quezon', '', 'End User'),
(294, 'WRIGHT BUILDER', 'Paranas, Samar', '', 'End User'),
(295, 'EDA CONSTRUCTION', 'MAcalelon,Quezon', '', 'End User'),
(296, 'M.EDG c/o MARIO ROCHA', 'Marinduque', '', 'End User'),
(297, 'QUALITY CERAMICS INC. c/o GINA', 'Gomez Ext. Red-v, Lucena City', '(042) 373-5978', 'End User'),
(298, 'JUAN CANTOS', 'Mayao Castillo,Lucena City', '', 'End User'),
(299, 'CNC CONSTRUCTION & DEV\'T CORP.', '62D Tuazon St., Brgy. Lourdes Quezon City', '0977-2744-594', 'End User'),
(300, 'MICHAEL BUENAVENTURA', 'Purok Masaya,Lucena City', '0933-150-1869', 'End User'),
(301, 'M.EDG c/o NOEMI REY', 'Marinduque', '', 'Hardware'),
(302, 'REY DE OCAMPO', 'Lucena City', '0942-461-5819', 'End User'),
(303, 'GEORKIMART c/o JANE CHUA', 'Lucena City', '', 'End User'),
(304, 'ENGR. HOMER GONZALES', 'Polillo,Quezon', '0939-9385-466', 'Hardware-A'),
(305, 'RONALDO BULFA', 'Lopez,Quezon', '0919-9116-968', 'End User'),
(306, 'EDGAR MARASIGAN', 'San Narciso,Quezon', '0909-9681-832', 'End User'),
(307, 'M.EDG c/o LORIMER RODAS', 'Marinduque', '', 'Hardware'),
(308, 'EDDIE BAÑADERA', 'Lucena City', '', 'End User'),
(309, 'WILLIE PAGSUYUIN', 'Lucena City', '0950-430-9128', 'End User'),
(310, 'RICHARD GOMEZ', 'Lucena City', '0950-430-9421', 'End User'),
(311, 'ENGR. CHRISTOPHER COMIA', 'Lucena City', '0917-522-9429', 'Contractor'),
(312, 'EDISON DE MESA', 'Tagkawayan,Quezon', '0948-942-2118', 'End User'),
(313, 'RAFA RAQUEL', 'Lucena City', '0946-319-6859', 'End User'),
(314, 'LEO RAMOS', 'Mayao Castillo,Lucena City', '0946-504-1255', 'End User'),
(315, 'JAAP GENERAL MERCHANDISE', 'Paete St., Rosario Village Ilayang Iyam Lucena City', '0908-867-0802', 'End User'),
(316, 'ARLYN CABANA', 'PatelSt., Alpsville 3 Subd., Lucena City', '0942-2064-466', 'End User'),
(317, 'RUBEN ZARA', 'Lucena City', '', 'End User'),
(318, 'RICHARD FORTIFAES', 'Lucena City', '', 'End User'),
(319, 'PEPE ORIOLA', 'Lucena City', '0918-798-9421', 'End User'),
(320, 'CARLITO BALANAY', 'Lucena City', '0998-886-6459', 'End User'),
(321, 'ENGR. ARVIN AYALA', 'Pagbilao,Quezon', '', 'Hardware-A'),
(322, 'ROY LUNA', 'Calauag,Quezon', '0917-850-3175', 'End User'),
(323, 'MARK ALLAN ADAM', 'Lucena City', '0922-830-7862', 'End User'),
(324, 'VINCENT ARANILLA', 'Lucena City', '0925-516-0014', 'End User'),
(325, 'VINCENT ARANILLA', 'Lucena City', '0925-516-0014', 'End User'),
(326, 'EDWIN CANTOS', 'Lucena City', '0910-9798-288', 'End User'),
(327, 'ARA MABUTING', 'Tayabas City', '0950-5712-698', 'End User'),
(328, 'JOSEPH MANAO', 'Sariaya,Quezon', '', 'End User'),
(329, 'OBET DURANTE', 'Silver Creek Subd., Brgy. Bocohan Lucena City', '0946-589-0469', 'End User'),
(330, 'EFREN CANILLO', 'Padre Burgos Quezon', '0916-171-0579', 'End User'),
(331, 'DR. ALBERT FULLANTE', 'Phase 8 Calmar Lucena City', '0908-374-8082', 'End User'),
(332, 'LAUDELITO ABEJUELA', 'Polillo,Quezon', '', 'End User'),
(333, 'ELLEN BORJA', 'Sta. Elena  Camarines , Norte', '', 'End User'),
(334, 'DENNIS WARIZA', 'Paraiso Beach Sariaya,Quezon', '0950-351-0823', 'End User'),
(335, 'REY ROMERO', 'Brgy., Talisay , San Francisco ,Quezon', '0917-702-0997', 'End User'),
(336, 'NBL FUEL STATION', 'Don Abella Drive Brgy. 9,Rotonda Catanauan,Quezon', '315-8274', 'Hardware-A'),
(337, 'GONZALO RACA', 'Tayabas,Quezon', '0920-969-1925', 'End User'),
(338, 'REY ROMERO', 'Brgy., Talisay San Francisco,Quezon', '0917-702-0997', 'End User'),
(339, 'FERNEL PIZARRA', 'Brgy. San Isidro sta Cruz,Marinduque', '0977-383-5654', 'End User'),
(340, 'ROMMEL LOZANO', 'Catanauan,Quezon', '0932-864-5518', 'End User'),
(341, 'NILO NARVAEZ', 'Lucena City', '0946-8063-079', 'End User'),
(342, 'VINCENT MONTEROLA c/o GRACE TAN', 'Pagbilao, Quezon', '0910-963-6700/ Lloyd', 'End User'),
(343, 'BOMEL CONSTRUCTION', 'Lucena City', '(042) 710-9632', 'End User'),
(344, 'FELY ABADILLA', 'Catanauan,Quezon', '0908-374-8082', 'End User'),
(345, 'QUALITY CERAMICS INC. c/o JANE/RICKY', 'Gomez Ext. Red-V,Lucena City', '(042) 373-5798', 'Hardware'),
(346, 'ONESTEEL TRADING', 'Kanluran Mayao,Lucena City', '', 'Hardware'),
(347, 'M.EDG c/o NIDA TABURNAL', 'Marinduque', '', 'End User'),
(348, 'CARLO PADERON', 'Lucena City', '', 'End User'),
(349, 'BELEN BULAWAN', 'Ibabang Iyam, Lucena City', '0942-4529-724', 'End User'),
(350, 'NASUGBO HARDWARE', 'Catanauan,Quezon', '0908-884-6725', 'End User'),
(351, 'LEONCI GUTIERREZ', 'PAGBILAO,QUEZON', '', 'End User'),
(352, 'LEO SALVADOR', 'Lucena City', '0947-766-6626', 'End User'),
(353, 'NILON GONZALES', 'Silangang Mayao Lucena City', '', 'End User'),
(354, 'WILMA ESTUITA', 'Lucena City', '0919-9601-235', 'End User'),
(355, 'ENGR. LORENZO RIVADULLA', 'Lucena City', '0999-8872506', 'Hardware-B'),
(356, 'RAMON PUACHE', 'Unisan,Quezon', '', 'End User'),
(357, 'MARILOU ABADO', 'Brgy., Ibabang Alsam,Tayabas City', '0939-919-9560', 'End User'),
(358, 'DONNABEL C. ZOLETA', 'Mauban,Quezon', '0918-630-0809', 'End User'),
(359, 'MACEDOÑA SIOCO', 'Cotta,Lucena City', '0918-4248-321', 'End User'),
(360, 'SEVILLA\'S CATERING RESORT', 'Domoit Lucena City', '', 'End User'),
(361, 'DAN ARGOSO', 'Lopez,Quezon', '', 'End User'),
(362, 'MACEDOÑA SIOCO', 'Cotta, Lucena City', '', 'End User'),
(363, 'NERI GONZALES', 'Mauban,Quezon', '', 'End User'),
(364, 'ONIX VILLAVERDE', 'Lucena City', '', 'End User'),
(365, 'RUBEN ZARA', 'Lucena City', '', 'End User'),
(366, 'SHERILY MENDOZA', 'Lucena City', '', 'End User'),
(367, 'DARIO REVILLOSA', 'Lucena City', '', 'End User'),
(368, 'NICK BRIONES', 'Mulanay,Quezon', '', 'End User'),
(369, 'PIO ABEJO', 'Lucena City', '', 'End User'),
(370, 'GINA PANTOJA', 'Lucena City', '', 'End User'),
(371, 'JD RAMOS BUILDERS', 'Candelaria,Quezon', '', 'End User'),
(372, 'CHARINE JUMAWAN', 'PAGBILAO ,QUEZON', '0918-6922-650', 'End User'),
(373, 'CHA JUMAWAN', 'PAGBILAO,QUEZON', '0918-6922-650', 'End User'),
(374, 'MARIE CHEDD VERGARA', 'Lucena City', '', 'End User'),
(375, 'MCC CHURCH MAUBAN', 'Mauban,Quezon', '0919-003-6050', 'End User'),
(376, 'BOGS ENCONMIENDA', 'Lucena City', '0928-612-4207', 'End User'),
(377, 'ENGR. NEMECIO AZUL', 'Talipan Pagbilao,Quezon', '0926-2787956/ 0910-985-1162-Mang Delfin', 'End User'),
(378, 'PATRICK PALCISO', 'Lucena City', '', 'End User'),
(379, 'CHRISTIAN SEGUI', 'Lopez,Quezon', '0999-967-7869', 'End User'),
(380, 'LUCENA MARKTOWN INC. c/o VENUS', 'Gomez Extn., Red-V, Lucena City', '(042) 373-0915', 'Hardware'),
(381, 'LEO SALVADOR', 'Lucena City', '', 'End User'),
(382, 'ALEJANDRO OPIS HARDWARE', 'Torrijos,Marinduque', '0929-394-9732', 'End User'),
(383, 'HERMES HERVERA', 'Purok ibaiw Brgy. Ilayang Dupay Lucena City', '0929-6295-558', 'End User'),
(384, 'DR. RENATO VERGARA', 'Lucena City', '0922-814-8212', 'End User'),
(385, 'REYMARK DELOS SANTOS', 'Lucena City', '', 'End User'),
(386, 'M.EDG c/o MA\'AM ABET', 'Marinduque', '', 'Hardware'),
(387, 'CELERINA CHUA', 'Lucena City', '0956-031-5019', 'End User'),
(388, 'NENIKO CONSTRUCTION', 'Gumaca,Quezon', '0919-282-6845', 'End User'),
(389, 'GERRY ELEAZAR', 'Tayabas City', '0923-492-3855', 'End User'),
(390, 'PILIPINO HARDWARE & CONST.SUPPLY', 'Lucena City', '', 'Hardware-A'),
(391, 'MARITES GERARMAN', 'Aurora,Quezon', '0912-6913-621', 'End User'),
(392, 'JONAS MALIZON', 'Pagbilao,Quezon', '', 'End User'),
(393, 'KOOPNAMAN', 'Lucena City', '', 'End User'),
(394, 'YAKAP AT HALIK MULTI-PURPOSE COOPERATIVE', 'Padre Burgos,Quezon', '0946-4842-707', 'End User'),
(395, 'PNL HARDWARE', 'Lucena City', '', 'End User'),
(396, 'CHAR REAL ESTATE DEALER c/o  ELVIRA A SALES', 'Rm. 307 ancom Bldg. Merchan cor. Evang. St. Lucena City', '0925-776-2398', 'End User'),
(397, 'GERARDO NAVELA', 'Lucena City', '', 'End User'),
(398, 'HONEY YU', 'Lucena City', '', 'Hardware-B'),
(399, 'RODNEY CALONG', 'Mauban,Quezon', '0908-2064-049', 'End User'),
(400, 'Mc Macale', 'Lucena City', '7106903', 'End User'),
(401, 'Melchor Alferez', 'Mauban ,Quezon', '', 'End User'),
(402, 'M.EDG c/o Renzi Rosas', 'Marinduque', '', 'End User'),
(403, 'LUCILA ILAO', 'Lucena City', '', 'End User'),
(404, 'M.EDG c/o Rucs', 'Marinduque', '', 'End User'),
(405, 'LIBERTY REFAZO\'S GEN.MDSE.', 'Perez,Quezon', '0947-7877-436', 'End User'),
(406, 'M.EDG c/o SIR PETER', 'Marinduque', '', 'Contractor'),
(407, 'M.EDG c/o MARIA RODELAS', 'Marinduque', '', 'Hardware'),
(408, 'LUCENA MARKTOWN INC. c/o RHELYN', 'Gomez Extn., Red-V,Lucena City', '(042) 373-0915/ 710-4628', 'Hardware'),
(409, 'EMPIRE OIL INTEGRATED MFG. CORP.', 'diversion Road Brgy., Silangang Mayao Lucena City', '(042) 717-2053 / 717-3634/ 785-6703', 'End User'),
(410, 'JCPC POULTRY KING FARM CORP.', 'Brgy., Gag-An Anilao, Ilo-Ilo', '0915-6522-872-NiÑA', 'Hardware-A'),
(411, 'JOHANNA\'S CHICKEN PROCESSING CENTER', 'Tiaong,Quezon', '0915-6522-872-Niña', 'End User'),
(412, 'LEONCIO GUTIERREZ', 'Brgy., Bantigue Pagbilao,Quezon', '0910-8822-637', 'End User'),
(413, 'EFREN QUIZADA c/o ESCUDERO', 'Talipan ,Pagbilao,Quezon Near Tropical ', '0907-260-7635', 'End User'),
(414, 'Mc Macale', 'Lucena City', '09124577', 'End User'),
(415, 'BONG CALIXTRO', 'Brgy., Limbon Sariaya,Quezon', '0917-503-8742', 'End User'),
(416, 'RUBEN BATANES', 'Mulanay,Quezon', '', 'End User'),
(417, 'LOLOY ABREGO', 'Talipan, Pagbilao,Quezon', '0949-947-5192', 'End User'),
(418, 'MIRIAM HERRERA', 'Lucena City', '0915-958-9249', 'End User'),
(419, 'JEFF VALENZUELA', 'Lucena City', '', 'End User'),
(420, 'ALDRIN GRIEGO', 'Lucena City', '', 'End User'),
(421, 'MIDAS', 'Guinyangan,Quezon', '0998-8521-622', 'End User'),
(422, 'MAY ALEGRIA', 'South Gate Subd., Brgy. Calumpang Tayabas City', '0915-9741-106', 'End User'),
(423, 'Ryan Limbo', 'Lucena City', '0956-7708-730', 'End User'),
(424, 'MANUEL ACESOR', 'Intertown Homes Pagbilao,Quezon', '0917-886-8475', 'End User'),
(425, 'RONALD FABI', 'Lucena City', '', 'End User'),
(426, 'BELLA MUSNI', 'Lucena City', '', 'End User'),
(427, 'M.EDG c/o REBECCA MONROYO', 'Laylay Port, Marinduque', '', 'Hardware'),
(428, '4M', 'Lucena City', '0939-903-4287', 'End User'),
(429, 'B-VALM CONSTRUCTION & SUPPLY', 'Pagbilao,Quezon', '0933-861-0059/ Maam Maris', 'End User'),
(430, 'GERALDINE ALPAY', 'Lucena City', '', 'End User'),
(431, 'TCMC', 'Tayabas,City', '', 'End User'),
(432, 'RUEL ABLAÑA', 'Lucena City', '0921-364-5914', 'End User'),
(433, 'RYAN LIMBO', 'Lucena City', '', 'End User'),
(434, 'MEAN SACOP', 'Regis Compound,Lucena City', '0909-881-8894', 'End User'),
(435, 'RODELA LIMPIN', 'Lucena City', '0907-420-8583', 'End User'),
(436, 'PAULA LIM HARDWARE', 'Boac, Marinduque', '0922-531-3125', 'End User'),
(437, 'SKYCRAPER', 'Marinduque', '0950-8495-258', 'End User'),
(438, 'PS ENGRACIA', 'Pagbilao,Quezon', 'Residential', 'Hardware-A'),
(439, 'ANGELITA BO', 'Lucena City', '', 'End User'),
(440, 'ENGR. PAGLICAWAN', 'Lucena City', '', 'Hardware-B'),
(441, 'ALBAN NANTES JR.', 'Sampaloc,Quezon', '0929-3186-474', 'Contractor'),
(442, 'HAROLD ALMACEN', 'Mauban,Quezon', '0930-6642-858', 'End User'),
(443, 'JCPC POULTRY KING FARM CORP.', 'Brgy.,Gag-An Anilao,Ilo-Ilo', '0915-6522-872-Niña', 'Hardware-A'),
(444, 'CORAZON REBLEZA', 'Mogpog,Marinduque', '0919-745-7926', 'End User'),
(445, 'ROBIN PORLAY', 'Lucena City', '0948-914-6276', 'End User'),
(446, 'JOCELYN JALIQUE', 'Sta.Elena,Camarines Norte', '0935-351-8276', 'End User'),
(447, 'ABUNDIO YANILLA', 'Tayabas,Quezon', '0928-325-3846', 'End User'),
(448, 'SHOPRITE', 'Lucena City', '', 'Hardware'),
(449, 'FLORANTE LORESTO', 'Buenavista,Quezon', '0909-326-4290', 'End User'),
(450, 'AR. EDUARD BOLIMA', 'Pagbilao,Quezon', '0921-550-2016', 'Hardware-B'),
(451, 'ROMULO MATIBAG', 'Purok Rosal, Sil.Mayao Lucena City', '0908-664-4984', 'End User'),
(452, 'EMMA EMBERSON', 'Unisan,Quezon', '0950-147-3088', 'End User'),
(453, 'NETS LUNAR', 'Purok Talisay Brgy., Talao2x ', '0999-1886-060', 'End User'),
(454, 'BRENDA QUIZON', 'Mauban ,Quezon', '', 'Hardware-A'),
(455, 'EDGAR PORNASDORO', 'Mayao, Castillo, Lucena City', '0956-953-9205', 'End User'),
(456, 'ENGR. JOBERT RIVADULLA', 'Lucena City', '0918-962-4202', 'Hardware-B'),
(457, 'M.EDG. c/o LENLY LECAROZ', 'Marinduque', '', 'Hardware'),
(458, 'JOSEPH REGIO', 'Lucena City', '0920-869-3164', 'End User'),
(459, 'YAKAP AT HALIK MULTI-PURPOSE COOP.', 'Padre Burgos,Quezon', '0946-4842-707', 'Contractor'),
(460, 'NIÑEL PEDRO', 'Lucena City', '', 'Contractor'),
(461, 'OUR LADY OF PEÑAFRANCIA PARISH', 'Lucena City', '0998-576-4838', 'Contractor'),
(462, 'ANTHONY FIDEL', 'Lucena City', '0950-135-8421', 'End User'),
(463, 'MERCY PIÑON', 'Camarines Norte', '0950-357-3929', 'End User'),
(464, 'M.EDG c/o DANNY RED', 'Marinduque', '', 'Hardware'),
(465, 'M.EDG c/o AQUA GEN', 'Marinduque', '', 'Hardware'),
(466, 'REY ALARAS', 'Unisan,Quezon', '0996-693-6301', 'End User'),
(467, 'LORNA REYES', 'Tayabas City', '0942-047-2093', 'End User'),
(468, 'RME POULTRY c/o Glenn Arrabe', 'Nagcarlan,Laguna', '0917-353-7130', 'Hardware-B'),
(469, 'MARCEL CONSTANTINO', 'Lucena City', '', 'Contractor'),
(470, 'EDIRIC ARIMADO', 'Lucban,Quezon', '0975-089-1981', 'End User'),
(471, 'Godofredo Rustria', 'Lucena City', '', 'End User'),
(472, 'LOREMER MACUNAT', 'Marinduque', '', 'End User'),
(473, 'JOSEPH LACERNA', 'Mogpog,Marinduque', '0909-3357-802/0948-842-7255', 'End User'),
(474, 'NOMER PARAISO', 'Lucena City', '0909-124-9080', 'End User'),
(475, 'PABLO BAUTISTA', 'Lucena City', '0908-629-9578', 'End User'),
(476, 'RED-V HARDWARE', 'Lucena City', '', 'End User'),
(477, 'ADRIAN BALMES', 'Lucena City', '', 'Contractor'),
(478, 'RONALD URGUELLES', 'Mauban,Quezon', '0946-208-7754', 'End User'),
(479, 'STA. ANA c/o JOJO CASTRO', 'Tayabas City', '0910-404-4608', 'End User'),
(480, 'EDITH CAMPOS', 'Domoit,Lucena City', '0917-845-2916', 'Contractor'),
(481, 'JOSEPH PAÑERO', 'Lucena City', '0938-456-7798', 'End User'),
(482, 'MACARIO SIMATA', 'Lucena City', '', 'End User'),
(483, 'MICHAEL P. LOREDO', 'Sariaya,Quezon', '', 'End User'),
(484, 'QUALITY CERAMICS INC. c/o VINA', 'Lucena City', '(042) 373-5798', 'Hardware'),
(485, 'NOEL ROPE', 'Pagbilao,Quezon', '0929-438-5758', 'End User'),
(486, 'JULIET ADELIN c/o LOREMER MACUNAT', 'Mogpog, Marinduque', '0946-421-4814', 'End User'),
(487, 'ONIE CONSTANTINO', 'Pagbilao,Quezon', '', 'End User'),
(488, 'TONY SANGALANG', 'Lucena City', '', 'End User'),
(489, 'ROLANDO RODRIGUEZ,JR.', 'Bahamas St., Better Living', '0948-028-3002', 'End User'),
(490, 'GEDMAR TRADING', 'Lopez,Quezon', '', 'Hardware-B'),
(491, 'CHRISTOPHER NAÑEZ', 'Lucban,Quezon', '', 'End User'),
(492, 'YAKAP AT HALIK c/o JUAN CORONADO', 'Padre Burgos,Quezon', '', 'End User'),
(493, 'L.S. ABELAR CONSTRUCTION', 'Lucena City', '', 'Contractor'),
(494, 'JEAN CASTILLO', 'Lucena City', '0928-192-2670', 'End User'),
(495, 'Lucena Marktown c/o Julie', 'Lucena City', '', 'End User'),
(496, 'BOYET BISCOCHO', 'Tayabas City', '0938-788-5238', 'End User'),
(497, 'TEYET  ALUFERA', 'East Orient Subd., Dalampasigan Sariaya,Quezon', '0928-520-5502', 'End User'),
(498, 'QUALITY CERAMICS,INC', 'Gomez Extension Red-V Lucena City', '660-2979', 'Hardware');

-- --------------------------------------------------------

--
-- Table structure for table `gatepass`
--

CREATE TABLE `gatepass` (
  `id` int(255) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `TelNo` varchar(255) DEFAULT NULL,
  `Project` varchar(255) DEFAULT NULL,
  `SO` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `VehicleType` varchar(255) DEFAULT NULL,
  `Plate` varchar(255) DEFAULT NULL,
  `PO` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PrintStatus` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `Color` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inventorylist`
--

CREATE TABLE `inventorylist` (
  `id` int(255) NOT NULL,
  `DateReceived` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `Coilno` varchar(255) DEFAULT NULL,
  `Thickness` varchar(255) DEFAULT NULL,
  `Width` varchar(255) DEFAULT NULL,
  `BeginningLengthM` varchar(255) DEFAULT NULL,
  `BeginningWeightTon` varchar(255) DEFAULT NULL,
  `Yield` varchar(255) DEFAULT NULL,
  `ActualWeightTon` varchar(255) DEFAULT NULL,
  `RemainingLengthM` varchar(255) DEFAULT NULL,
  `Remarks` varchar(255) DEFAULT NULL,
  `DateOpened` varchar(255) DEFAULT NULL,
  `ORnumber` varchar(255) DEFAULT NULL,
  `POnumber` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventorylist`
--

INSERT INTO `inventorylist` (`id`, `DateReceived`, `Color`, `Coilno`, `Thickness`, `Width`, `BeginningLengthM`, `BeginningWeightTon`, `Yield`, `ActualWeightTon`, `RemainingLengthM`, `Remarks`, `DateOpened`, `ORnumber`, `POnumber`) VALUES
(8, '12-27-2017', 'Choco Brown', 'ZD17101609AZD', '0.40', '915', '0', '0', '373.77188', '-0.4252068', '1107.3911', 'Unused Coil', '02-25-2019', '5236', ''),
(9, '12-7-2017', 'Red Dragon', 'Y16102220-A2', '0.40', '915', '1632', '4.5930', '355.32333', '3.5250', '1574.62', 'Used Coil', '09-05-2019', '5184', ''),
(10, '7-31-2019', 'Red Dragon', 'XJ18051411-2B', '0.35', '1220', '1425', '4.6680', '305.2699', '4.6680', '1425', 'Unused Coil', '', '', ''),
(11, '3-22-2019', 'Red Dragon', 'ZD18100211AZD', '0.35', '1220', '1360', '4.3780', '310.64413', '4.3780', '1360', 'Unused Coil', '', '', ''),
(12, '3-22-3019', 'Red Dragon', 'ZD181002116ZD', '0.35', '1220', '1380', '4.4420', '310.67087', '4.4420', '1380', 'Unused Coil', '', '', ''),
(13, '3-22-2019', 'Red Dragon', 'ZD18100211BZD', '0.35', '1220', '1330', '4.2820', '310.6025', '4.2820', '1330', 'Unused Coil', '', '', ''),
(14, '6-8-2019', 'Red Dragon', 'ZD19042406AZD', '0.40', '1220', '1260', '0', '0', '0', '', 'Unused Coil', '7-18-19', '8313', ''),
(15, '6-8-2019', 'Red Dragon', 'ZD19042406BZD', '0.40', '1220', '1220', '4.2100', '289.78622', '4.1889', '1213.9', 'Unused Coil', '', '', ''),
(16, '6-8-2019', 'Red Dragon', 'ZD19042407AZD', '0.40', '1220', '1250', '4.3500', '287.35632', '4.3499784', '1250.0', 'Unused Coil', '', '', ''),
(17, '6-8-2019', 'Red Dragon', 'ZD19042407BZD', '0.40', '1220', '1240', '0', '0', '0', '', 'Unused Coil', '08-22-2019', '8313', ''),
(18, '6-8-2019', 'Red Dragon', 'ZD19042408BZD', '0.40', '1220', '1220', '4.2080', '289.92395', '2.7330', '', 'Used Coil', '09-19-2019', '8313', ''),
(19, '6-8-2019', 'Red Dragon', 'ZD19042409AZD', '0.40', '1220', '1250', '4.3660', '286.30325', '4.3660', '1250', 'Unused Coil', '', '', ''),
(20, '6-7-2019', 'Red Dragon', 'ZD19042402AZD', '0.50', '1220', '900', '0', '0', '0', '', 'Unused Coil', '7-26-19', '8308', ''),
(21, '6-7-2019', 'Red Dragon', 'ZD19042402BZD', '0.50', '1220', '980', '4.4940', '218.06854', '4.4940', '980', 'Unused Coil', '', '', ''),
(22, '6-7-2019', 'Red Dragon', 'ZD19042403ZD', '0.50', '1220', '970', '4.4340', '218.7641', '4.4340', '970', 'Unused Coil', '', '', ''),
(23, '10-16-2018', 'Red Dragon', 'Y18063008-C2', '0.60', '1220', '764', '4.2020', '181.81818', '4.2020', '764', 'Unused Coil', '', '', ''),
(24, '10-16-2018', 'Red Dragon', 'Y18063001-B2', '0.60', '1220', '811', '4.5200', '179.42477', '1.4345', '', 'Used Coil', '7-26-19', '6878', ''),
(25, '5-7-2018', 'Jade Green', 'ZD18010717AZD', '0.40mm', '915mm', '1450', '3.9560', '366.53183', '3.8860', '', 'Used Coil', '', '6741', ''),
(26, '5-7-2018', 'Jade Green', 'ZX180127A15', '0.35', '1220', '1205', '3.8540', '312.66217', '3.8540', '1205', 'Unused Coil', '', '', ''),
(27, '5-23-2018', 'Jade Green', 'ZX180127A18', '0.35', '1220', '1217', '3.8960', '312.37167', '3.8960', '1217', 'Unused Coil', '', '', ''),
(28, '3-22-2019', 'Jade Green', '2ZD18062126AZD', '0.35', '1220', '1340', '4.2000', '319.04764', '4.2000', '1340', 'Unused Coil', '', '', ''),
(29, '3-25-2019', 'Jade Green', '2ZD18062125BZD', '0.35', '1220', '1295', '4.0520', '319.59525', '4.0520', '1295', 'Unused Coil', '', '', ''),
(30, '3-25-2019', 'Jade Green', '2ZD18062212BZD', '0.35', '1220', '1325', '4.1520', '319.12332', '4.1520', '1325', 'Unused Coil', '', '', ''),
(31, '5-22-2019', 'Jade Green', 'ZD19030425AZD', '0.40', '1220', '1110', '0', '0', '0', '', 'Unused Coil', '', '', ''),
(32, '5-22-2019', 'Jade Green', 'ZD19030434AZD', '0.40', '1220', '1130', '4.0160', '281.3745', '4.0160', '1130', 'Unused Coil', '', '', ''),
(33, '5-22-2019', 'Jade Green', 'ZD19030431AZD', '0.40', '1220', '1120', '3.9840', '281.1245', '3.9840', '1120', 'Unused Coil', '', '', ''),
(34, '5-22-2019', 'Red Dragon', 'ZD19030424BZD', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '09-11-2019', '8100', ''),
(35, '5-22-2019', 'Jade Green', 'ZD19030429AZD', '0.40', '1220', '1140', '4.0420', '282.0386', '4.0420', '1140', 'Unused Coil', '', '', ''),
(36, '5-25-2019', 'Jade Green', 'ZD19030422AZD', '0.40', '1220', '1140', '4.0460', '281.75977', '4.0460', '1140', 'Unused Coil', '', '', ''),
(37, '6-7-2019', 'Jade Green', 'ZD19021941ZD', '0.50', '1220', '975', '0', '0', '0', '', 'Unused Coil', '7-27-19', '', ''),
(38, '6-7-2019', 'Jade Green', 'ZD19021931BZD', '0.50', '1220', '835', '0', '0', '0', '', 'Unused Coil', '7-26-19', '', ''),
(39, '6-7-2019', 'Jade Green', 'ZD19021933BZD', '0.50', '1220', '945', '4.3840', '215.55658', '4.3840', '945', 'Unused Coil', '', '', ''),
(40, '5-22-2019', 'Jade Green', '2ZD18111320ZD', '0.60', '1220', '865', '0', '0', '0', '0', 'Unused Coil', '7-30-19', '7417', ''),
(41, '5-22-2019', 'G.I.', '2ZD181111318BZD', '0.60', '1220', '765', '4.2320', '180.7656', '4.2320', '765', 'Unused Coil', '', '', ''),
(42, '5-22-2019', 'Jade Green', '2ZD18111318AZD', '0.60', '1220', '760', '0', '0', '0', '', 'Unused Coil', '08-31-2019', '7417', ''),
(43, '5-22-2019', 'Jade Green', '2ZD18111317AZD', '0.60', '1220', '755', '4.1780', '180.70848', '4.1780', '755', 'Unused Coil', '', '', ''),
(44, '7-25-19', 'Red Dragon', 'ZD18052432BZD', '.4', '1220', '1120', '3.9840', '281.1245', '3.9840', '1120', 'Unused Coil', '', '', ''),
(45, '07-25-18', 'Foam Green', 'ZD18052438ZD', '0.40', '1220', '1160', '4.1120', '282.10117', '2.6820', '', 'Used Coil', '08-17-2019', '6450', '1849'),
(46, '12-20-2018', 'Foam Green', '2ZD18061635ZD', '0.40', '1220', '1295', '4.5820', '282.6277', '4.5820', '1295', 'Unused Coil', '', '', ''),
(47, '12-20-2018', 'Jade Green', '2ZD18061636BZD', '0.40', '1220', '1335', '0', '0', '0', '', 'Unused Coil', '08-30-2019', '7263', '1948'),
(48, '12-20-2018', 'Foam Green', '2ZD18061638BZD', '0.40', '1220', '1080', '3.8480', '280.66528', '3.8480', '1080', 'Unused Coil', '', '', ''),
(49, '12-20-2018', 'Foam Green', '2ZD18061639AZD', '0.40', '1220', '1120', '3.9800', '281.40704', '*W2*', '', 'Used Coil', '', '', ''),
(50, '09-12-2018', 'Choco Brown', 'XJ18051708-1B', '0.40', '915', '1489', '4.0400', '368.56436', '0', '0', 'Used Coil', '', '', ''),
(51, '1-11-2019', 'Choco Brown', '2ZD1811020AZD', '0.35', '1220', '1400', '4.5140', '310.1462', '4.5140', '1400', 'Unused Coil', '', '', ''),
(52, '1-11-2019', 'Choco Brown', '2ZD18110121AZD', '0.35', '1220', '1400', '4.5140', '310.1462', '4.5140', '1400', 'Unused Coil', '', '', ''),
(53, '1-11-2019', 'Choco Brown', '2ZD18110122ZD', '0.35', '1220', '1395', '4.4960', '310.27582', '4.4960', '1395', 'Unused Coil', '', '', ''),
(54, '2-11-2019', 'Red Dragon', 'ZD18100420BZD', '0.40', '1220', '0', '0', '279.5031', '-3.4270544', '-951.7001', 'Unused Coil', '07-26-2019', '', ''),
(55, '2-11-2019', 'Choco Brown', 'ZD18052326BZD', '0.40', '1220', '0', '0', '282.62866', '-2.5867596', '-731.10016', 'Unused Coil', '07-26-2019', '', ''),
(56, '6-15-2019', 'Red Dragon', 'ZD19000042738BZD', '0.40', '1220', '1230', '0', '0', '0', '0', 'Unused Coil', '08-06-2019', '', ''),
(57, '6-15-2019', 'Choco Brown', 'ZD19042737BZD', '0.40', '1220', '1210', '4.1840', '289.19693', '4.1840', '1210', 'Unused Coil', '', '', ''),
(58, '6-15-2019', 'Choco Brown', 'ZD19042733ZD', '0.40', '1220', '1380', '4.8060', '287.14105', '4.8060', '1380', 'Used Coil', '', '', ''),
(59, '6-15-2019', 'Choco Brown', 'ZD19042732AZD', '0.40', '1220', '1250', '4.3300', '288.6836', '4.3300', '1250', 'Unused Coil', '', '', ''),
(60, '6-15-2019', 'Choco Brown', 'ZD19042731AZD', '0.40', '1220', '1220', '4.2140', '289.51114', '4.138149', '1198.0402', 'Unused Coil', '', '', ''),
(61, '6-15-2019', 'Choco Brown', 'ZD19042730AZD', '0.40', '1220', '1500', '5.2140', '287.68698', '5.2140', '1500', 'Unused Coil', '', '', ''),
(62, '7-09-2019', 'Choco Brown', 'ZD19033009AZD', '0.50', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '7-29-19', '8507', ''),
(63, '7-09-2019', 'Choco Brown', 'ZD19033001AZD', '0.50', '1220', '970', '4.4260', '219.1595', '4.355731', '954.6', 'Unused Coil', '', '', ''),
(64, '7-09-2019', 'Choco Brown', 'ZD19033003BZD', '0.50', '1220', '880', '4.0180', '219.01443', '4.0180', '880', 'Unused Coil', '', '', ''),
(65, '7--09-2019', 'Choco Brown', 'ZD19033017AZD', '0.50', '1220', '955', '0', '0', '-4.3133597', '-931.45013', 'Unused Coil', '', '', ''),
(66, '7-09-2019', 'Choco Brown', 'ZD19033017AZD', '0.50', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '09-14-2019', '8507', '2012'),
(68, '9-12-2018', 'Choco Brown', 'ZD180107177AZD', '0.40', '915', '1450', '3.9560', '366.53183', '3.9560', '1450', 'Unused Coil', '', '', ''),
(69, '05-25-19', 'Choco Brown', 'Y18072121-B2', '0.60', '1220', '803', '4.4060', '182.25146', '4.4060', '803', 'Used Coil', '', '', ''),
(70, '05-25-19', 'Choco Brown', 'Y18072121-A2', '0.60', '1220', '804', '4.4220', '181.81819', '4.4220', '804', 'Unused Coil', '', '', ''),
(71, '05-25-19', 'Choco Brown', 'Y18072117-B2', '0.60', '1200', '819', '4.4920', '182.32413', '4.4920', '819', 'Unused Coil', '', '', ''),
(72, '05-25-19', 'Choco Brown', 'Y18072124-A2', '0.60', '1220', '861', '4.7460', '181.41594', '4.7460', '861', 'Unused Coil', '', '', ''),
(73, '05-31-19', 'Choco Brown', 'Y18072122-A2', '0.60', '1220', '806', '4.4420', '181.4498', '4.4420', '806', 'Unused Coil', '', '', ''),
(74, '12-27-2017', 'Cozy Blue', 'ZD17101609AZD', '0.40', '915', '1750', '4.6820', '373.77188', '2.8225', '1107.3911', 'Used Coil', '02-25-2019', '5236', ''),
(75, '07-24-19', 'Cozy Blue', '2ZD18052612AZD', '0.35', '1220', '1360', '4.3260', '314.37817', '4.3260', '1360', 'Unused Coil', '', '', ''),
(76, '03-25-19', 'Cozy Blue', '2ZD18120134BZD', '0.35', '1220', '1355', '4.3160', '313.9481', '4.3160', '1355', 'Unused Coil', '', '', ''),
(77, '03-25-19', 'Cozy Blue', '2ZD18120132AZD', '0.35', '1220', '1320', '4.1920', '314.8855', '4.1920', '1320', 'Unused Coil', '', '', ''),
(78, '02-13-19', 'Cozy Blue', 'ZD18100315ZD', '0.40', '1220', '1280', '4.5640', '280.45572', '1.4826226', '438.57986', 'Unused Coil', '', '', ''),
(79, '02-13-19', 'Cozy Blue', '2ZD18062206BZD', '0.40', '1220', '1170', '4.1660', '280.84494', '4.1660', '1170', 'Unused Coil', '', '', ''),
(80, '05-27-19', 'Cozy Blue', 'ZD19021913ZD', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '09-07-2019', '8265', ''),
(81, '05-27-19', 'Cozy Blue', 'ZD19021917ZD', '0.50', '1220', '985', '4.4780', '219.96426', '4.4780', '985', 'Unused Coil', '', '', ''),
(82, '05-27-19', 'Cozy Blue', 'ZD19021904AZD', '0.50', '1220', '972', '4.5160', '215.23473', '4.5160', '972', 'Used Coil', '', '', ''),
(83, '07-09-2018', 'Cozy Blue', 'ZD18013107ZD', '0.60', '1220', '863', '4.7680', '180.99832', '4.1120', '', 'Used Coil', '08-02-2019', '6412', '1870'),
(84, '07-09-2018', 'Cozy Blue', 'ZD18013104AZD', '0.60', '1220', '800', '4.3260', '184.92833', '4.3260', '800', 'Unused Coil', '', '', ''),
(85, '03-25-2019', 'Cozy Blue', 'Y18072306-C2', '0.60', '1220', '792', '4.3420', '182.40442', '4.3420', '792', 'Unused Coil', '', '', ''),
(86, '03-25-2019', 'Cozy Blue', 'Y18060245-A2', '0.60', '1220', '959', '5.1620', '185.7807', '5.1620', '959', 'Unused Coil', '', '', ''),
(87, '01-31-2019', 'Pearl White', 'ZD18062030AZD', '0.40', '1220', '1220', '4.2900', '284.3823', '1.8437294', '524.3201', 'Used Coil', '', '', ''),
(88, '01-31-2019', 'Cozy Blue', 'ZD18093001BZD', '0.40', '1220', '810', '2.8880', '280.47092', '2.4330509', '682.4', 'Unused Coil', '', '', ''),
(90, '06-17-2019', 'Cozy Blue', 'ZD19042530AZD', '0.40', '1220', '1220', '4.2380', '287.87164', '4.2380', '1220', 'Unused Coil', '', '', ''),
(91, '06-17-2019', 'Pearl White', 'ZD19042530BZD', '0.40', '1220', '1240', '4.3140', '287.43625', '4.2970223', '1235.12', 'Unused Coil', '', '', ''),
(92, '01-31-2019', 'Pearl White', 'ZD18093022ZD', '0.50', '1220', '1045', '4.8040', '217.52707', '4.770349', '1037.68', 'Unused Coil', '', '', ''),
(93, '01-31-2019', 'Pearl White', 'ZD18093018BZD', '0.50', '1220', '940', '4.2820', '219.52359', '4.2820', '940', 'Unused Coil', '', '', ''),
(94, '01-31-2019', 'Pearl White', 'ZD18093008BZD', '0.50', '1220', '945', '4.3300', '218.24481', '3.8992908', '851.0', 'Unused Coil', '', '', ''),
(95, '03-26-2019', 'Pearl White', 'Y18102618-A2', '0.50', '1220', '905', '4.2440', '213.24223', '4.209673', '897.68', 'Unused Coil', '', '', ''),
(96, '03-26-2019', 'Red Dragon', 'Y18102619-A2', '0.50', '1220', '1003', '4.7040', '213.2228', '4.3400', '', 'Unused Coil', '7-15-19', '7927', ''),
(97, '03-26-2019', 'Pearl White', '2ZD19010237AZD', '0.60', '1220', '840', '4.5500', '184.61537', '4.14375', '765.0', 'Unused Coil', '', '', ''),
(98, '05-27-2019', 'Pearl White', 'Y19031229-2', '0.60', '1220', '965', '5.2640', '183.32066', '5.2640', '965', 'Unused Coil', '', '', ''),
(99, '05-27-2019', 'Pearl White', 'Y19031230-A2', '0.60', '1220', '887', '4.8600', '182.51028', '4.8600', '887', 'Unused Coil', '', '', ''),
(100, '07-22-2017', 'Terracotta', 'Y16102239-A2', '0.40', '915', '1586', '4.4130', '359.3927', '4.4130', '1586', 'Unused Coil', '', '', ''),
(101, '12-13-2017', 'Terracotta', 'ZD17100521AZD', '0.40', '1220', '1200', '4.2780', '280.5049', '4.2780', '1200', 'Unused Coil', '', '', ''),
(102, '12-13-2017', 'Terracotta', 'ZD17100517ZD', '0.40', '1220', '1235', '4.4160', '279.66486', '4.4160', '1235', 'Unused Coil', '', '', ''),
(103, '04-27-2019', 'Terracotta', 'ZD19021945AZD', '0.50', '1220', '940', '4.2720', '220.03746', '2.7400', '', 'Used Coil', '08-16-2019', '8033', ''),
(104, '05-08-19', 'Terracotta', 'Y18122317-A2', '0.60', '1220', '943', '5.1340', '183.67744', '5.1340', '943', 'Unused Coil', '', '', ''),
(105, '05-08-2019', 'Terracotta', 'Y18122316-B2', '0.60', '1220', '923', '5.0520', '182.69992', '5.0520', '923', 'Unused Coil', '', '', ''),
(106, '08-01-2018', 'Ivory', '2ZD18052442AZD', '0.40', '1220', '1180', '4.1420', '284.8865', '1.4700', '*W2*', 'Used Coil', '', '6607', ''),
(107, '08-01-2018', 'Ivory', '2ZD18052440BZD', '0.40', '1220', '1165', '4.1600', '280.0481', '3.1990', '1165', 'Used Coil', '', '', ''),
(108, '08-20-2018', 'Ivory', '2ZD18052441AZD', '0.40', '1220', '1190', '4.2440', '280.39584', '4.2440', '1190', 'Used Coil', '', '', ''),
(109, '05-31-2019', 'Ivory', 'Y18121722-A2', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '7-29-19', '8286', ''),
(110, '05-31-2019', 'Ivory', 'Y18122505-B2', '0.50', '1220', '944', '4.3420', '217.41133', '1.1205', '944', 'Used Coil', '', '', ''),
(111, '05-31-2019', 'Ivory', 'Y18121725-B2', '0.50', '1220', '1044', '4.7580', '219.41992', '4.7580', '1044', 'Unused Coil', '', '', ''),
(112, '05-31-2019', 'Ivory', 'Y18102711-B2', '0.50', '1220', '975', '4.5520', '214.19156', '4.5520', '975', 'Unused Coil', '', '', ''),
(113, '06-17-2019', 'Ivory', 'ZD19021817AZD', '0.60', '1220', '810', '4.4000', '184.09091', '4.4000', '810', 'Unused Coil', '', '', ''),
(114, '06-17-2019', 'Ivory', 'ZD19021816BZD', '0.60', '1220', '810', '4.4540', '181.85901', '4.4540', '810', 'Used Coil', '', '', ''),
(115, '06-17-2019', 'Ivory', 'ZD19021818AZD', '0.60', '1220', '0', '0', '0', '0', '', 'Unused Coil', '7-30-19', '8337', ''),
(116, '06-17-2019', 'Ivory', 'ZD19021828ZD', '0.60', '1220', '825', '4.4660', '184.72906', '4.4660', '825', 'Unused Coil', '', '', ''),
(117, '03-27-2019', 'Red Dragon', '2ZD18113013BZD', '0.40', '1220', '1240', '0', '0', '-2.726272', '-769.0', 'Unused Coil', '', '', ''),
(118, '01-16-2019', 'Bloody Red', '2ZD18103151BZD', '0.60', '1220', '780', '4.3260', '180.30513', '1.5200', '706.52997', 'Used Coil', '7-18-2019', '7344', ''),
(119, '01-16-2019', 'Bloody Red', '2ZD18103150AZD', '0.60', '1220', '800', '4.4160', '181.15942', '4.4160', '800', 'Unused Coil', '', '', ''),
(120, '03-21-2018', 'Charcoal Gray', '1712CC-A1358', '0.40', '1220', '1230', '4.5860', '268.20758', '2.5740', '', 'Used Coil', '08-02-2019', '5850', ''),
(121, '11-21-2018', 'Charcoal Gray', 'ZD18032335BZD', '0.40', '1220', '1240', '4.4440', '279.02792', '4.4440', '1240', 'Unused Coil', '', '', ''),
(122, '11-21-2018', 'Charcoal Gray', 'ZD18032336BZD', '0.40', '1220', '1240', '4.4300', '279.90973', '4.4300', '1240', 'Unused Coil', '', '', ''),
(123, '11-21-2018', 'Charcoal Gray', 'ZD18032333BZD', '0.40', '1220', '1240', '4.4260', '280.16266', '4.4260', '1240', 'Unused Coil', '', '', ''),
(124, '11-21-2018', 'Charcoal Gray', 'ZD18032327BZD', '0.40', '1220', '1206', '4.3000', '280.46512', '4.3000', '1206', 'Unused Coil', '', '', ''),
(125, '11-21-2018', 'Charcoal Gray', 'ZD18062125AZD', '0.40', '1220', '1225', '4.3760', '279.936', '4.3760', '1225', 'Unused Coil', '', '', ''),
(126, '03-30-2019', 'Charcoal Gray', 'ZD19021501AZD', '0.50', '1220', '965', '4.4680', '215.9803', '4.4680', '965', 'Unused Coil', '', '', ''),
(127, '', 'Charcoal Gray', '', '', '', '', '', '', '', '', 'Used Coil', '', '', ''),
(128, '04-26-2019', 'Charcoal Gray', 'ZD19021507BZD', '0.50', '1220', '970', '4.4540', '217.78177', '4.4540', '970', 'Unused Coil', '', '', ''),
(129, '04-26-2019', 'Charcoal Gray', 'ZD19021505BZD', '0.50', '1220', '970', '4.4240', '219.2586', '4.4240', '970', 'Unused Coil', '', '', ''),
(130, '04-27-2019', 'Charcoal Gray', 'ZD19021502AZD', '0.50', '1220', '952', '4.4100', '215.87302', '4.4100', '952', 'Unused Coil', '', '', ''),
(131, '05-08-2019', 'Charcoal Gray', 'ZD19010533BZD', '0.60', '1220', '820', '4.4340', '184.9346', '4.4340', '820', 'Unused Coil', '', '', ''),
(132, '05-08-2019', 'Charcoal Gray', 'ZD19010534BZD', '0.60', '1220', '785', '4.2620', '184.18582', '4.2620', '785', 'Unused Coil', '', '', ''),
(133, '05-27-2019', 'G.I.', 'SLC3632-C', '0.80', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '07-24-2019', '8264', '65 K PSI'),
(134, '03-29-2019', 'G.I.', '9Y000787L-1-B-SONIC', '0.80', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '07-25-2019', '67442', '50K PSI'),
(135, '03-29-2019', 'G.I.', '9Y0007090L-2-B-SONIC', '0.80', '1220', '486.33', '3.7700', '129.0', '3.7700', '486.33', 'Unused Coil', '', '', ''),
(136, '03-29-2019', 'G.I.', '9Y007941-2-C-SONIC', '0.80', '1220', '506.325', '3.9250', '129.0', '2.5815', '506.325', 'Used Coil', '', '50K PSI', ''),
(137, '03-29-2019', 'G.I.', '9Y0007941-2-B-SONIC', '0.80', '1220', '493.425', '3.8250', '129.0', '3.8250', '493.425', 'Unused Coil', '', '', ''),
(138, '03-29-2019', 'G.I.', '9Y000790L2-A-SONIC', '0.80', '1220', '486.975', '3.7750', '129.0', '3.7750', '486.975', 'Unused Coil', '', '', ''),
(139, '03-29-2019', 'G.I.', '9Y000787L-1-A-SONIC', '0.80', '1220', '385.71', '2.9900', '129.0', '2.9900', '385.71', 'Unused Coil', '', '', ''),
(140, '04-01-2019', 'G.I.', 'SLJ3598-C', '1.00', '1220', '591', '5.6750', '104.14097', '2.4750872', '-3.74', 'Used Coil', '07-23-2019', '7954', '80K PSI'),
(141, '06-21-2018', 'G.I.', 'C3B024641-B SONIC', '1.00', '1220', '523', '4.9050', '106.625885', '4.9050', '523', 'Unused Coil', '', '', ''),
(142, '06-21-2018', 'G.I.', 'C3B024602-A SONIC', '1.00', '1220', '530', '4.9800', '106.425705', '4.9800', '530', 'Unused Coil', '', '', ''),
(143, '06-21-2018', 'G.I.', 'CB024641-A SONIC', '1.00', '1220', '524', '4.9150', '106.61241', '4.9150', '524', 'Unused Coil', '', '', ''),
(144, '03-23-2019', 'G.I.', 'CCH040481-B SONIC', '1.00', '1220', '528.41', '4.9850', '105.99999', '4.9850', '528.41', 'Unused Coil', '', '', ''),
(145, '03-23-2019', 'G.I.', 'CCH015692-A SONIC', '1.00', '1220', '494.49', '4.6650', '106.0', '4.6650', '494.40', 'Unused Coil', '', '', ''),
(146, '03-23-2019', 'G.I.', 'CCH015662-A SONIC', '1.00', '1220', '483.36', '4.5600', '106.0', '4.5600', '483.36', 'Unused Coil', '', '', ''),
(147, '03-23-2019', 'G.I.', 'CCH015692-B SONIC', '1.00', '1220', '488.13', '4.6050', '106.0', '4.6050', '488.13', 'Unused Coil', '', '', ''),
(148, '03-23-2019', 'G.I.', 'CCH015662-B SONIC', '1.00', '1220', '488.13', '4.6050', '106.0', '4.6050', '488.13', 'Unused Coil', '', '', ''),
(149, '07-10-2019', 'Pearl White', 'ZD19042529AZD', '0.40', '1220', '1270', '4.384', '289.6898', '4.384', '1270', 'Unused Coil', '', '', ''),
(150, '07-10-2019', 'Pearl White', 'ZD19042529BZD', '0.40', '1220', '1285', '4.430', '290.06772', '4.430', '1285', 'Unused Coil', '', '', ''),
(151, '07-10-2019', 'Pearl White', 'ZD19042528ZD', '0.40', '1220', '1395', '4.810', '290.02078', '4.810', '1395', 'Unused Coil', '', '', ''),
(152, '07-10-2019', 'Red Dragon', '2ZD19010510ZD', '0.60', '1220', '800', '4.328', '184.84288', '4.328', '800', 'Unused Coil', '', '', ''),
(153, '07-10-2019', 'Red Dragon', '2ZD19010504BZD', '0.60', '1220', '815', '4.422', '184.30574', '4.422', '815', 'Unused Coil', '', '', ''),
(154, '07-11-2019', 'G.I.', '190410AB0830', '0.80', '1220', '576', '4.375', '131.65715', '4.375', '576', 'Unused Coil', '', '', ''),
(155, '07-11-2019', 'G.I.', 'SLK3561-E', '1.00', '1220', '477', '4.585', '104.0349', '', '477', 'Used Coil', '08-03-2019', '8549', '65K PSI'),
(156, '07-11-2019', 'Red Dragon', '2ZD19010501BZD', '0.60', '1220', '828', '4.484', '184.65656', '4.484', '828', 'Unused Coil', '', '', ''),
(157, '07-11-2019', 'Red Dragon', '2ZD19010502BZD', '0.60', '1220', '790', '4.276', '184.7521', '4.276', '790', 'Unused Coil', '', '', ''),
(158, '07-11-2019', 'Red Dragon', '2ZD19010501AZD', '0.60', '1220', '840', '4.554', '184.45323', '4.554', '840', 'Unused Coil', '', '', ''),
(159, '07-11-2019', 'Red Dragon', '2ZD19010452BZD', '0.60', '1220', '825', '4.462', '184.89467', '4.462', '825', 'Unused Coil', '', '', ''),
(161, '12-7-2017', 'Red Dragon', 'HD3171123B9-2', '0.35', '1220', '0', '0', '322.09302', '0', '', 'Unused Coil', '', '', ''),
(162, '12-7-2017', 'Red Dragon', 'Y16102225-B2', '0.40', '915', '1744', '0', '0', '0', '', 'Unused Coil', '10-17-2018', '', ''),
(163, '2-28-2018', 'Red Dragon', 'HD3171123B9-2', '0.35', '1220', '1385', '0', '322.09', '0', '', 'Unused Coil', '3-1-2019', '', ''),
(164, '', 'Red Dragon', '', '', '', '', '', '', '', '', 'Used Coil', '', '', ''),
(165, '6-8-2019', 'Red Dragon', 'ZD19042408AZD', '0.40', '1220', '1210', '0', '288.65', '0', '', 'Unused Coil', '6-28-2019', '', ''),
(166, '6-7-2019', 'Red Dragon', 'ZD19042333AZD', '0.50', '1220', '0', '0', '218.39', '0', '', 'Unused Coil', '7-9-2019', '', ''),
(167, '10-16-2018', 'Red Dragon', 'Y18063003-A2', '0.60', '1220', '0', '0', '178.37', '0', '', 'Unused Coil', '6-4-2019', '', ''),
(168, '11-28-2017', 'Bloody Red', 'ZD17100735ZD', '0.40', '915', '0', '0', '366.05', '0', '', 'Unused Coil', '12-15-2018', '', ''),
(169, '9-22-2017', 'Jade Green', 'HD3170528A17-1', '0.35', '1220', '0', '0', '310.01', '0', '', 'Unused Coil', '3-16-2018', '', ''),
(170, '5-7-2018', 'Jade Green', 'ZX180127A16', '0.35', '1220', '1193', '3.8460', '310.19', '2.2500', '', 'Used Coil', '6-11-2019', '6048', '1833'),
(171, '5-22-2019', 'Jade Green', 'ZD19030428AZD', '0.40', '1220', '0', '0', '281.28', '0', '', 'Unused Coil', '7-6-2019', '', ''),
(172, '6-5-2019', 'Jade Green', 'ZD19021932BZD', '0.50', '1220', '0', '0', '215.54', '0', '', 'Unused Coil', '7-3-2019', '', ''),
(173, '5-22-2019', 'Jade Green', '2ZD18111319AZD', '0.60', '1220', '0', '0', '177.62', '0', '', 'Unused Coil', '6-18-2019', '', ''),
(174, '7-13-2018', 'Jade Green', 'XJ18051347-2A', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '4-16-2019', '', ''),
(175, '7-25-2018', 'Jade Green', 'ZD18052433BZD', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '10-3-2018', '', ''),
(176, '12-27-2017', 'Choco Brown', 'ZD17100712BZD', '0.40', '915', '1650', '4.4660', '369.46', '0.6315', '', 'Used Coil', '9-15-2018', '5236', ''),
(177, '01-30-2018', 'Choco Brown', 'HD3171006A10-1', '0.35', '1220', '1440', '4.4900', '320.71', '3.4250', '', 'Used Coil', '05-14-2019', '5346', '1776'),
(178, '2-9-2019', 'Choco Brown', 'Y18101822-A2', '0.50', '1220', '0', '0', '213.64', '0', '', 'Unused Coil', '6-27-2019', '', ''),
(179, '2-9-2019', 'Choco Brown', 'Y18102821-A2', '0.50', '1220', '0', '0', '215.19', '0', '', 'Unused Coil', '7-8-2019', '', ''),
(180, '6-27-2018', 'Red Dragon', 'HD3171126C1', '0.60', '1220', '0', '0', '181.38', '0', '', 'Unused Coil', '6-27-2019', '', ''),
(181, '12-27-2017', 'Choco Brown', 'ZD17101609AZD', '0.40', '915', '0', '0', '0', '-0.4252068', '1107.3911', 'Unused Coil', '2-25-2019', '5236', ''),
(182, '7-24-3018', 'Choco Brown', '2ZD18052438AZD', '0.35', '1220', '0', '0', '0', '0', '', 'Unused Coil', '7-11-2019', '6459', ''),
(183, '2-13-2019', 'Cozy Blue', '2ZD18062153AZD', '0.40', '1220', '0', '0', '282.05', '0', '', 'Unused Coil', '7-5-2019', '', ''),
(184, '5-27-2019', 'Cozy Blue', 'ZD19021908ZD', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '7-10-2019', '8265', ''),
(185, '07-09-2018', 'Cozy Blue', '350217110099200', '0.60', '1220', '0', '0', '0', '0', '', 'Unused Coil', '5-21-2019', '6412', ''),
(186, '', 'Cozy Blue', '', '', '', '', '', '', '', '', 'Unused Coil', '', '', ''),
(187, '7-24-2018', 'Pearl White', 'XJ18051222-A', '0.40', '1220', '0', '0', '281.68', '', '', 'Unused Coil', '3-18-2019', '', ''),
(188, '07-24-2018', 'Pearl White', 'XJ18051223-1A', '0.40', '1220', '1340', '4.7040', '284.86', '1.0900', '', 'Unused Coil', '5-04-2019', '6460', '1884-A'),
(189, '09-12-2018', 'Red Dragon', 'HD3171005A2-2', '0.50', '1220', '0', '0', '217.18', '', '', 'Unused Coil', '11-27-2018', '', ''),
(190, '09-22-2018', 'Red Dragon', 'HD3171005A-18-2', '0.50', '1220', '', '', '219.57', '', '', 'Unused Coil', '3-11-19', '', ''),
(191, '02-11-2019', 'Pearl White', 'Y18041324-A2', '0.60', '1220', '825', '4.5120', '182.85', '3.1070', '', 'Used Coil', '3-13-19', '7683', ''),
(192, '02-11-2019', 'Pearl White', 'Y18041321-A2', '0.60', '1220', '830', '4.5620', '181.94', '', '*W2*', 'Used Coil', '04-04-19', '7683', ''),
(193, '03-26-2019', 'Pearl White', '2ZD19010239ZD', '0.60', '1220', '832', '0', '0', '0', '', 'Unused Coil', '04-03-2019', '7927', ''),
(194, '6-7-2016', 'Terracotta', 'Y16031817-B2', '0.40', '915', '1525', '4.2150', '361.80307', '1.8450', '', 'Used Coil', '4-24-2017', '', ''),
(195, '12-13-2017', 'Terracotta', 'ZD17100523BZD', '0.40', '1220', '1240', '4.4540', '278.40', '1.0350', '', 'Used Coil', '06-29-2019', '5199', ''),
(196, '04-27-2019', 'Terracotta', 'ZD19021945BZD', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '05-24-2019', '8033', ''),
(197, '05-08-2019', 'Terracotta', 'Y18122316-A2', '0.60', '1220', '939', '5.1360', '182.83', '4.1350', '', 'Used Coil', '05-09-2019', '8057', ''),
(198, '06-07-2017', 'Ivory', 'HD3170226A2', '0.40', '915', '1830', '4.8600', '376.54', '0.7920', '', 'Used Coil', '07-01-2017', '4353', ''),
(199, '07-31-2018', 'Ivory', '2ZD18052510BZD', '0.40', '1220', '0', '0', '279.92', '0', '', 'Unused Coil', '05-04-2019', '', ''),
(200, '07-31-2018', 'Ivory', '2ZD18052506BZD', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '07-02-2019', '6496', ''),
(201, '05-31-2019', 'Ivory', 'Y18122504-B2', '0.50', '1220', '0', '0', '218.13', '0', '', 'Unused Coil', '06-20-2019', '', ''),
(202, '06-17-2019', 'Ivory', 'ZD19021830ZD', '0.60', '1220', '0', '0', '0', '0', '0.0', 'Unused Coil', '06-18-2019', '', ''),
(203, '09-20-2015', 'Ivory', '914120-2-HY', '0.40', '915', '0', '0', '0', '0', '', 'Unused Coil', '06-03-2019', '', ''),
(204, '12-27-2017', 'Bloody Red', 'HD3170321A5-2', '0.40', '915', '1735', '4.5550', '380.90', '3.337', '*W2*', 'Used Coil', '06-22-2019', '5236', ''),
(206, '04-27-2019', 'Bloody Red', '2ZD19030205ZD', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '06-28-2019', '', ''),
(207, '05-23-2018', 'Bloody Red', 'ZD18012920BZD', '0.60', '1220', '0', '0', '181.45', '', '', 'Unused Coil', '04-24-2019', '', ''),
(208, '01-16-2019', 'Bloody Red', '2ZD18103148AZD', '0.60', '1220', '0', '0', '180.19', '0', '', 'Unused Coil', '05-30-2019', '', ''),
(209, '11-20-2018', 'Charcoal Gray', 'ZD1803239AZD', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '03-22-2019', '7165', ''),
(210, '03-30-2019', 'Charcoal Gray', 'ZD19021501BZD', '0.50', '1220', '0', '0', '0', '0', '', 'Unused Coil', '03-30-2019', '', ''),
(211, '05-08-2019', 'Charcoal Gray', 'ZD19010532BZD', '0.60', '1220', '825', '4.4640', '184.81', '4.1080', '', 'Used Coil', '06-19-2019', '8058', ''),
(212, '05-27-2019', 'G.I.', 'SLC3632-A', '0.80', '1220', '0', '0', '129.44', '0', '', 'Unused Coil', '07-05-2019', '', ''),
(213, '03-29-2019', 'G.I.', '9Y000787L-1-C-SONIC', '0.80', '1220', '', '0', '', '0', '', 'Unused Coil', '06-17-2019', '', ''),
(214, '04-01-2019', 'G.I.', 'SLJ3598-B', '1.00', '1220', '0', '0', '0', '0', '', 'Unused Coil', '06-22-2019', '', ''),
(215, '06-21-2018', 'G.I.', 'C3B024602-B SONIC', '1.00', '1220', '400', '3.7550', '106.52', '0.1073', '', 'Used Coil', '02-20-2019', '58577', '50K PSI'),
(216, '7-16-19', 'Ivory', 'IVORY40-305A', '.4', '305', '268', '.24', '1116.6667', '', '268', 'Used Coil', '7-16-19', '', ''),
(217, '7-16-19', 'Ivory', 'IVORY40-305B', '.4', '305', '268.72', '.24', '1119.6667', '-0.088289134', '-98.799995', 'Used Coil', '', '', ''),
(218, '7-16-19', 'Ivory', 'IVORY50-305A', '.5', '305', '244.3', '.28', '872.5', '0.04194843', '36.600014', 'Used Coil', '', '', ''),
(219, '7-16-19', 'Pearl White', 'WHITE40-305A', '.4', '305', '236.61', '.21', '1126.7144', '-0.14546357', '-163.89', 'Used Coil', '', '', ''),
(220, '7-16-19', 'Pearl White', 'WHITE40-305B', '.4', '305', '134.97', '.12', '1124.75', '.12', '134.97.12', 'Used Coil', '', '', ''),
(221, '7-16-19', 'Pearl White', 'WHITE40-305C', '.4', '305', '134.95', '.12', '1124.5834', '0.08396887', '94.42999', 'Used Coil', '', '', ''),
(222, '7-16-19', 'Pearl White', 'WHITE50-305A', '.5', '305', '157.05', '.18', '872.5', '-0.0033581527', '-2.9300041', 'Used Coil', '', '', ''),
(223, '7-16-19', 'Pearl White', 'WHITE50-305B', '.5', '305', '157.05', '.18', '872.5', '-0.028595984', '-24.949997', 'Used Coil', '', '', ''),
(224, '7-16-19', 'Pearl White', 'WHITE50-305C', '.5', '305', '157.05', '.18', '872.5', '0.031518627', '27.500011', 'Used Coil', '', '', ''),
(225, '4-16-19', 'Jade Green', 'XJ8051347-2A', '.4', '1220', '421.38', '1.5', '280.92', '1.5', '421.38', 'Used Coil', '', '', ''),
(226, '7-16-19', 'Bloody Red', '914120-2-HY', '.4', '915', '1054.91', '2.89', '365.02075', '2.89', '1054.91', 'Used Coil', '', '', ''),
(227, '2-11-19', 'Pearl White', 'Y18041324-A2', '.6', '1220', '336.44', '1.84', '182.84782', '1.84', '336.44', 'Used Coil', '', '', ''),
(228, '2-11-19', 'Pearl White', 'Y18041321-A2', '.6', '1220', '673.18', '3.7', '181.94054', '3.7', '673.18', 'Used Coil', '', '', ''),
(229, '7-31-19', 'Ivory', '2ZD18052510BZD', '.4', '1220', '100.771', '.36', '279.91943', '.36', '100.771', 'Used Coil', '', '', ''),
(230, '6-17-19', 'Ivory', 'ZD19021830ZD', '.6', '1220', '36.436', '.2', '182.18001', '-0.093753435', '0.0', 'Used Coil', '', '', ''),
(233, '7-17-19', 'G.I.', '190410AB0800', '.8', '1220', '588', '4.47', '131.54362', '4.47', '588', 'Used Coil', '', '', ''),
(234, '7-17-19', 'G.I.', '190410AB0860', '.8', '1220', '584', '4.445', '131.38358', '4.445', '584', 'Used Coil', '', '', ''),
(235, '7-17-19', 'G.I.', 'SLK3560-E', '1.00', '1220', '0', '0', '104.3956', '0', '0', 'Unused Coil', '', '', ''),
(236, '7-17-19', 'G.I.', 'SLK3560-C', '1.00', '1220', '0', '0', '104.19425', '0', '0', 'Unused Coil', '', '', ''),
(237, '7-17-19', 'G.I.', 'SLK3557-E', '1.00', '1220', '0', '0', '104.13408', '0', '0', 'Unused Coil', '', '', ''),
(238, '6-30-19', 'Choco Brown', 'HD3171125A27-1', '0.6', '1220', '810', '4.45', '380.90', '0.73528147', '5.040016', 'Used Coil', '7-22-19', '', ''),
(239, '07-18-2019', 'Jade Green', 'ZD19032909BZD', '0.40', '1220', '1125', '3.884', '289.64984', '3.884', '1125', 'Unused Coil', '', '', ''),
(240, '07-22-2019', 'Red Dragon', 'ZD19062622AZD', '0.40', '1120', '1230', '0', '0', '0', '0', 'Unused Coil', '05-08-2019', '', ''),
(241, '07-23-2019', 'Bloody Red', 'ZD19062621BZD', '0.40', '1220', '1230', '3.968', '309.97986', '3.4810', '1230', 'Used Coil', '', '', ''),
(242, '07-22-2019', 'Bloody Red', 'ZD19062621AZD', '0.40', '1220', '1310', '4.230', '309.69266', '4.230', '1310', 'Unused Coil', '', '', ''),
(243, '07-22-2019', 'Bloody Red', 'ZD19062619BZD', '0.40', '1220', '1205', '3.888', '309.92798', '3.888', '1205', 'Unused Coil', '', '', ''),
(244, '07-22-2019', 'Bloody Red', 'ZD19062619AZD', '0.40', '1220', '1180', '3.806', '310.03677', '3.806', '1180', 'Unused Coil', '', '', ''),
(245, '07-22-2019', 'Bloody Red', 'ZD19062618BZD', '0.40', '1220', '1165', '3.760', '309.84042', '3.760', '1165', 'Unused Coil', '', '', ''),
(246, '07-22-2019', 'Bloody Red', 'ZD19062620ZD', '0.40', '1220', '1480', '4.778', '309.75305', '4.778', '1480', 'Unused Coil', '', '', ''),
(247, '07-22-2019', 'Bloody Red', 'ZD19062618AZD', '0.40', '1220', '1350', '4.352', '310.20218', '4.352', '1350', 'Unused Coil', '', '', ''),
(248, '07-22-2019', 'Cozy Blue', '2ZD18111413BZD', '0.40', '1220', '1240', '4.378', '283.23438', '4.378', '1240', 'Used Coil', '', '', ''),
(249, '07-23-2019', 'Cozy Blue', '2ZD18111413AZD', '0.40', '1220', '0', '0', '0', '0', '', 'Unused Coil', '09-07-2019', '7426', '2019'),
(250, '07-22-2019', 'Cozy Blue', '2ZD18111411BZD', '0.40', '1220', '1165', '4.130', '282.0823', '4.130', '1165', 'Unused Coil', '', '', ''),
(251, '9-12-2018', 'Red Dragon', 'ZD18010717AZD', '0.40', '915', '1450', '0', '0', '0', '', 'Unused Coil', '7-24-19', '6741', '1892-R'),
(252, '5-22-2019', 'Jade Green', 'ZD19030428AZD', '0.40', '1220', '0', '0', '281.28', '0', '', 'Unused Coil', '7-6-2019', '', ''),
(253, '02-11-19', 'Choco Brown', 'ZD18100420BZD', '0.40', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '7-30-19', '7685', ''),
(254, '06-30-19', 'Choco Brown', 'HD3171125A27-1', '0.60', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '7-22-19', '6391', '1859'),
(255, '7-24-19', 'Cozy Blue', '2ZD18052438AZD', '0.35', '1220', '1300', '4.1860', '310.55902', '2.2285', '', 'Used Coil', '7-11-19', '6459', '1860'),
(256, '02-13-19', 'Cozy Blue', 'ZD18100315ZD', '0.40', '1220', '0', '0', '0', '0', '438.57986', 'Unused Coil', '7-27-19', '7692', ''),
(257, '8-1-2017', 'Pearl White', 'Y16102310-A2', '0.40', '915', '1609', '4.4910', '358.2721', '1.5290', '', 'Used Coil', '10-25-18', '4573', ''),
(258, '03-26-2019', 'Red Dragon', 'Y18102619-A2', '0.50', '1220', '1003', '0', '0', '0', '', 'Unused Coil', '7-15-19', '7927', ''),
(259, '03-26-19', 'Pearl White', 'Y18102619-A2', '0.50', '1220', '1003', '4.7040', '213.2228', '2.4480', '', 'Used Coil', '7-15-19', '7927', ''),
(260, '12-27-2017', 'Red Dragon', 'HD3170321A5-2', '0.40', '915', '1735', '4.5550', '380.90012', '3.3370', '', 'Unused Coil', '06-22-2019', '5236', ''),
(261, '9-20-2015', 'Bloody Red', '914120-2-HY', '0.40', '915', '1294', '3.5450', '365.02115', '2.9200', '', 'Used Coil', '6-3-2019', '', ''),
(262, '03-27-2019', 'Bloody Red', '2ZD18113013BZD', '0.40', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '7-22-2019', '7929', ''),
(263, '03-30-2019', 'Charcoal Gray', 'ZD19021502BZD', '0.50', '1220', '915', '4.2360', '216.00566', '2.9860', '', 'Used Coil', '08-02-2019', '7938', ''),
(264, '07-31-2019', 'Red Dragon', 'XJ18051411-1B', '0.35', '1220', '1429', '4.7020', '303.9132', '3.6235', '', 'Used Coil', '07-08-2019', '6497', '1869'),
(265, '08-19-2019', 'Red Dragon', 'ZD19062013BZD', '0.50', '1220', '900', '0', '0', '0', '', 'Unused Coil', '08-30-2019', '8965', '2032'),
(266, '09-12-2019', 'Jade Green', 'ZD18010717AZD', '0.40', '915', '1450', '3.9560', '366.53183', '3.5380', '', 'Used Coil', '07-24-2019', '6741', '1892-R'),
(267, '07-18-2019', 'Jade Green', 'ZD19032928AZD', '0.50', '1220', '850', '0', '0', '0', '', 'Unused Coil', '08-24-2019', '8585', '2017'),
(268, '02-11-2019', 'Choco Brown', 'ZD18052326BZD', '0.40', '1220', '0', '0', '0', '0', '0', 'Unused Coil', '08-27-2019', '7685', '1968'),
(269, '08-19-2019', 'Red Dragon', 'ZD19062007ZD', '0.50', '1220', '1180', '4.9240', '239.64258', '4.6810', '', 'Used Coil', '09-28-2019', '8965', '2032'),
(270, '10-03-2019', 'S/S MIRROR 304', 'S/S Matt 304', '0.60', '1220', '0', '0', '0', '-Infinity', '-4.88', 'Used Coil', '10-03-2019', '', ''),
(271, '10-04-2019', 'S/S MIRROR 304', 'S/S Mirror 304', '0.40', '1220', '0', '0', '0', '-Infinity', '-17.08', 'Used Coil', '', '', ''),
(272, '05-25-2019', 'Jade Green', 'ZD19030432BZD', '0.40', '1220', '1140', '4.0420', '282.0386', '', '', 'Used Coil', '', '', ''),
(273, '07-18-2019', 'Jade Green', 'ZD19032939BZD', '0.50', '1220', '850', '3.8720', '219.5248', '', '', 'Used Coil', '', '', ''),
(274, '08-19-2019', 'Jade Green', 'Y18121419-A2', '0.60', '1220', '927', '5.0640', '183.05687', '', '', 'Used Coil', '', '', ''),
(275, '09-11-2019', 'Choco Brown', 'ZD19073021BZD', '0.50', '1220', '918', '3.9840', '230.42169', '', '', 'Used Coil', '', '', ''),
(276, '01-31-2019', 'Pearl White', 'Y18101219-C2', '0.40', '1220', '1245', '4.5360', '274.47092', '', '*W2*', 'Used Coil', '', '', ''),
(277, '08-01-2019', 'Bloody Red', 'ZD19062041BZD', '0.50', '1220', '970', '4.0720', '238.21217', '', '', 'Used Coil', '', '', ''),
(278, '07-17-2019', 'G.I.', '190410AB0860', '0.80', '1220', '584', '4.4450', '131.38358', '', '', 'Used Coil', '', '65K PSI', '');

-- --------------------------------------------------------

--
-- Table structure for table `jobitem`
--

CREATE TABLE `jobitem` (
  `id` int(255) NOT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `itemName` varchar(255) DEFAULT NULL,
  `Thickness` varchar(255) DEFAULT NULL,
  `Width` varchar(255) DEFAULT NULL,
  `Length` varchar(255) DEFAULT NULL,
  `Tonnage` varchar(255) DEFAULT NULL,
  `LMS` varchar(255) DEFAULT NULL,
  `joborderno` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `joborder`
--

CREATE TABLE `joborder` (
  `id` int(255) NOT NULL,
  `FullName` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `TelNo` varchar(255) DEFAULT NULL,
  `Project` varchar(255) DEFAULT NULL,
  `DateCreated` varchar(255) DEFAULT NULL,
  `DateRelease` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `Reference` varchar(255) DEFAULT NULL,
  `SOno` varchar(255) DEFAULT NULL,
  `Time` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `PrintStatus` varchar(255) NOT NULL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `misclist`
--

CREATE TABLE `misclist` (
  `id` int(255) NOT NULL,
  `date` date DEFAULT NULL,
  `itemName` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `misclist`
--

INSERT INTO `misclist` (`id`, `date`, `itemName`, `quantity`, `price`, `category`) VALUES
(4, '2020-01-04', 'B.I. C-Purlins 1.00mm x 2\'\' x 3\'\' x 6m', '374', '494.40', 'miscStock'),
(5, '2019-11-04', 'B.I. C-Purlins 1.00mm x 2\" x 4\" x 6m', '321', '565.20', 'miscStock'),
(6, '2020-01-04', 'B.I C-Purlins 1.00mm x 2\" x 6\" x 6m', '1', '', 'miscStock'),
(7, '2019-11-04', 'B.I. C-Purlins 1.00mm x 2\" x 8\" x 6m', '51', '', 'miscStock'),
(8, '2019-11-04', 'B.I. C-Purlins 1.20mm x 2\" x 10\" x 6m', '126', '', 'miscStock'),
(9, '2020-01-04', 'G.I C-Purlins 1.20mm x 2\" x 3\" x 6m', '592', '', 'miscStock'),
(10, '2020-01-04', 'G.I. C-Purlins 1.20mm x 2\" x 4\" x 6m', '773', '', 'miscStock'),
(11, '2020-01-04', 'G.I. C-Purlins 1.20mm x 2\" x 6\" x 6m', '826', '', 'miscStock'),
(12, '2020-01-04', 'G.I. C-Purlins 1.20mm x 2\" x 8\" x 6m', '266', '', 'miscStock'),
(13, '2020-01-04', 'G.I. C-Purlins 1.20mm x 2\' x 10\" x 6m', '11', '', 'miscStock'),
(14, '2020-01-04', '10mm Insulation 2-Sided (1m x 50m)', '29', '', 'miscStock'),
(15, '2020-01-04', '10mm Insulation 1-Sided (1m x 50m)', '19', '', 'miscStock'),
(16, '2020-01-04', '5mm Insulation 2-Sided (1m x 50m)', '24', '', 'miscStock'),
(17, '2020-01-04', '5mm Insulation 1-Sided (1m x 50m)', '21', '', 'miscStock'),
(18, '2020-01-04', 'TEKSCRW 3\" Steel', '32000', '', 'miscStock'),
(19, '2020-01-04', 'TEKSCRW 2 -1/2 Steel ', '50000', '', 'miscStock'),
(20, '2020-01-04', 'TEKSCRW 2\" Steel', '48000', '', 'miscStock'),
(22, '2019-09-19', 'TEKSCRW 80mm- Wood ', '14,902', '', 'miscStock'),
(23, '2020-01-04', 'TEKSCRW  3\" Wood ', '38000', '', 'miscStock'),
(24, '2020-01-04', 'TEKSCRW 2-1/2\'\' Wood ', '62500', '1.75', 'miscStock'),
(25, '2020-01-04', 'TEKSCRW 2\" Wood ', '138000', '', 'miscStock'),
(26, '2020-01-04', 'Blind Rivets 5/32 x 1/2 (BOX)', '648', '', 'miscStock'),
(27, '2020-01-04', 'Drill Bit 5/32 (PCS)', '141', '', 'miscStock'),
(28, '2020-01-04', 'Tekscrew Adaptor (PCS)', '99', '', 'miscStock'),
(29, '2020-01-04', 'Silicone Rubber Sealant (PCS)', '780', '', 'miscStock'),
(30, '2020-01-04', 'Caulking Gun (PCS)', '22', '', 'miscStock'),
(32, '2020-01-04', 'Concrete Nail No.1 (KG)', '15.5', '', 'miscStock'),
(33, '2019-11-04', 'Gutter Strainer 3\"', '51', '', 'miscStock'),
(34, '2019-11-04', 'Gutter Strainer 4\"', '160', '', 'miscStock'),
(35, '2019-11-04', 'Gutter Strainer 2\"', '88', '', 'miscStock'),
(36, '2020-01-04', 'Downspout Connector 4\"', '74', '', 'miscStock'),
(37, '2020-01-04', 'Downspout Connector 2\"', '22', '', 'miscStock'),
(38, '2020-01-04', 'Downspout Connector 3\"', '24', '', 'miscStock'),
(39, '2020-01-04', 'Spray Paint-Bloody Red ', '31', '', 'miscStock'),
(40, '2020-01-04', 'Spray Paint-Choco Brown ', '111', '', 'miscStock'),
(41, '2020-01-04', 'Spray Paint-Charcoal Gray ', '17', '', 'miscStock'),
(42, '2020-01-04', 'Spray Paint-Cozy Blue ', '22', '', 'miscStock'),
(43, '2020-01-04', 'Spray Paint- Ivory ', '51', '', 'miscStock'),
(44, '2020-01-04', 'Spray Paint - Jade Green ', '29', '', 'miscStock'),
(45, '2020-01-04', 'Spray Paint - Pearl White ', '65', '', 'miscStock'),
(46, '2020-01-04', 'Spray Paint - Red Dragon ', '42', '', 'miscStock'),
(47, '2020-01-04', 'Spray Paint - Terracotta', '42', '', 'miscStock'),
(48, '2020-01-04', 'Plainsheet S/S Matte .60mm', '64', '', 'miscStock'),
(49, '2020-01-04', 'Plainsheet S/S Matte .50mm', '92', '', 'miscStock'),
(50, '2020-01-04', 'Plainsheet S/S Matte .40mm', '210', '', 'miscStock'),
(51, '2020-01-04', 'Plainsheet S/S Mirror .40mm', '209', '', 'miscStock'),
(53, '2020-01-04', 'J-BOLT 2-1/2', '40800', '5', 'miscStock'),
(54, '2020-01-04', 'Downspout Connector 4\" W/ Strainer', '192', '', 'miscStock'),
(55, '2020-01-04', 'Downspout Connector 2\" w/ Strainer', '95', '', 'miscStock'),
(56, '2020-01-04', 'Downspout Connector 3\" W/ Strainer', '76', '', 'miscStock');

-- --------------------------------------------------------

--
-- Table structure for table `pricelist`
--

CREATE TABLE `pricelist` (
  `id` int(255) NOT NULL,
  `itemCode` varchar(255) NOT NULL,
  `itemName` varchar(255) NOT NULL,
  `itemCategory` varchar(255) NOT NULL,
  `thickness` longtext NOT NULL,
  `width` longtext NOT NULL,
  `length` longtext NOT NULL,
  `price` longtext NOT NULL,
  `PriceCategory` varchar(255) DEFAULT NULL,
  `dividend` varchar(255) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pricelist`
--

INSERT INTO `pricelist` (`id`, `itemCode`, `itemName`, `itemCategory`, `thickness`, `width`, `length`, `price`, `PriceCategory`, `dividend`) VALUES
(44, 'TR35EU', 'Turin Rib 1220', 'Roofing', '0.35', '1130', '', '220', 'End User', NULL),
(45, 'TR40EU', 'Turin Rib 1220', 'Roofing', '0.40', '1130', '', '280', 'End User', NULL),
(46, 'TR50EU', 'Turin Rib 1220', 'Roofing', '0.50', '1130', '', '355', 'End User', NULL),
(47, 'TR60EU', 'Turin Rib 1220', 'Roofing', '0.60', '1130', '', '420', 'End User', NULL),
(54, 'CR35EU', 'Corrugated 1220', 'Roofing', '0.35', '1130', '', '220', 'End User', NULL),
(55, 'CR40EU', 'Corrugated 1220', 'Roofing', '0.40', '1130', '', '280', 'End User', NULL),
(56, 'CR50EU', 'Corrugated 1220', 'Roofing', '0.50', '1130', '', '355', 'End User', NULL),
(57, 'CR60EU', 'Corrugated 1220', 'Roofing', '0.60', '1130', '', '420', 'End User', NULL),
(58, 'GT40EU', 'Genova Tile', 'Roofing', '0.40', '1127', '', '320', 'End User', NULL),
(59, 'GT50EU', 'Genova Tile', 'Roofing', '0.50', '1127', '', '400', 'End User', NULL),
(60, 'GT60EU', 'Genova Tile', 'Roofing', '0.60', '1127', '', '475', 'End User', NULL),
(61, 'PD80K0.80EU', 'Prime Deck 80,000psi', 'Roofing', '0.80', '995', '', '540', 'End User', NULL),
(62, 'PD80K1.00EU', 'Prime Deck 80,000psi', 'Roofing', '1.00', '995', '', '670', 'End User', NULL),
(63, 'PD50K0.80EU', 'Prime Deck 50,000psi', 'Roofing', '0.80', '995', '', '495', 'End User', NULL),
(64, 'PD50K1.00EU', 'Prime Deck 50,000psi', 'Roofing', '1.00', '995', '', '610', 'End User', NULL),
(65, 'PC40EU', 'Prime Clad(Ordinary)', 'Roofing', '0.40', '255', '', '105', 'End User', NULL),
(66, 'PC50EU', 'Prime Clad(Ordinary)', 'Roofing', '0.50', '255', '', '115', 'End User', NULL),
(67, 'PC60EU', 'Prime Clad(Ordinary)', 'Roofing', '0.60', '255', '', '125', 'End User', NULL),
(68, 'PS4x8EU35', 'Plainsheet(4x8)', 'Bended', '0.35', '1220', '2440', '537', 'End User', NULL),
(69, 'PS4x8EU40', 'Plainsheet(4x8)', 'Bended', '0.40', '1220', '2440', '685', 'End User', NULL),
(70, 'PS4x8EU50', 'Plainsheet(4x8)', 'Bended', '0.50', '1220', '2440', '870', 'End User', NULL),
(71, 'PS4x8EU60', 'Plainsheet(4x8)', 'Bended', '0.60', '1220', '2440', '1025', 'End User', NULL),
(72, 'RC4018OEU', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '315', 'End User', NULL),
(73, 'RC4018OEU', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '365', 'End User', NULL),
(74, 'RR4048OEU', 'Bended', 'Bended', '0.40', '1220', '2440', '720', 'End User', NULL),
(75, 'RR4048SEU', 'Bended', 'Bended', '0.40', '1220', '2440', '865', 'End User', NULL),
(76, 'RR5048OEU', 'Bended', 'Bended', '0.50', '1220', '2440', '905', 'End User', NULL),
(77, 'RR5048SEU', 'Bended', 'Bended', '0.50', '1220', '2440', '1065', 'End User', NULL),
(78, 'RR6048OEU', 'Bended', 'Bended', '0.60', '1220', '2440', '1060', 'End User', NULL),
(79, 'RR6048SEU', 'Bended', 'Bended', '0.60', '1220', '2440', '1235', 'End User', NULL),
(80, 'RR4036OEU', 'Bended', 'Bended', '0.40', '915', '2440', '555', 'End User', NULL),
(81, 'RR4036SEU', 'Bended', 'Bended', '0.40', '915', '2440', '660', 'End User', NULL),
(82, 'RR4032OEU', 'Bended', 'Bended', '0.40', '813', '2440', '490', 'End User', NULL),
(83, 'RR4032SEU', 'Bended', 'Bended', '0.40', '813', '2440', '590', 'End User', NULL),
(84, 'RR5032OEU', 'Bended', 'Bended', '0.50', '813', '2440', '615', 'End User', NULL),
(85, 'RR5032SEU', 'Bended', 'Bended', '0.50', '813', '2440', '720', 'End User', NULL),
(86, 'RR6032OEU', 'Bended', 'Bended', '0.60', '813', '2440', '720', 'End User', NULL),
(87, 'RR6032SEU', 'Bended', 'Bended', '0.60', '813', '2440', '835', 'End User', NULL),
(88, 'RR4030OEU', 'Bended', 'Bended', '0.40', '763', '2440', '465', 'End User', NULL),
(89, 'RR4030SEU', 'Bended', 'Bended', '0.40', '763', '2440', '510', 'End User', NULL),
(90, 'RR5030OEU', 'Bended', 'Bended', '0.50', '763', '2440', '580', 'End User', NULL),
(91, 'RR5030SEU', 'Bended', 'Bended', '0.50', '763', '2440', '625', 'End User', NULL),
(92, 'RR6030OEU', 'Bended', 'Bended', '0.60', '763', '2440', '675', 'End User', NULL),
(93, 'RR6030SEU', 'Bended', 'Bended', '0.60', '763', '2440', '720', 'End User', NULL),
(94, 'RR4024OEU', 'Bended', 'Bended', '0.40', '610', '2440', '380', 'End User', NULL),
(95, 'RR4024SEU', 'Bended', 'Bended', '0.40', '610', '2440', '425', 'End User', NULL),
(96, 'RR5024OEU', 'Bended', 'Bended', '0.50', '610', '2440', '470', 'End User', NULL),
(97, 'RR5024SEU', 'Bended', 'Bended', '0.50', '610', '2440', '515', 'End User', NULL),
(98, 'RR6024OEU', 'Bended', 'Bended', '0.60', '610', '2440', '550', 'End User', NULL),
(99, 'RR6024SEU', 'Bended', 'Bended', '0.60', '610', '2440', '595', 'End User', NULL),
(100, 'RR4018OEU', 'Bended', 'Bended', '0.40', '457', '2440', '295', 'End User', NULL),
(101, 'RR4018SEU', 'Bended', 'Bended', '0.40', '457', '2440', '340', 'End User', NULL),
(102, 'RR4016OEU', 'Bended', 'Bended', '0.40', '407', '2440', '265', 'End User', NULL),
(103, 'RR4016SEU', 'Bended', 'Bended', '0.40', '407', '2440', '310', 'End User', NULL),
(104, 'RR5016OEU', 'Bended', 'Bended', '0.50', '407', '2440', '325', 'End User', NULL),
(105, 'RR5016SEU', 'Bended', 'Bended', '0.50', '407', '2440', '370', 'End User', NULL),
(124, 'RR4012OEU', 'Bended', 'Bended', '0.40', '305', '2440', '210', 'End User', '1'),
(125, 'RR6012OEU', 'Bended', 'Bended', '0.60', '305', '2440', '295', 'End User', '1'),
(126, 'RR5012OEU', 'Bended', 'Bended', '0.50', '305', '2440', '255', 'End User', '1'),
(127, 'RR409OEU', 'Bended', 'Bended', '0.40', '229', '2440', '165', 'End User', '1'),
(128, 'RR408OEU', 'Bended', 'Bended', '0.40', '203', '2440', '150', 'End User', '1'),
(129, 'RR508OEU', 'Bended', 'Bended', '0.50', '203', '2440', '180', 'End User', '1'),
(130, 'RR608OEU', 'Bended', 'Bended', '0.60', '203', '2440', '205', 'End User', '1'),
(131, 'RR406OEU', 'Bended', 'Bended', '0.40', '162', '2440', '120', 'End User', '1'),
(132, 'RR506OEU', 'Bended', 'Bended', '0.50', '162', '2440', '145', 'End User', '1'),
(133, 'RR606OEU', 'Bended', 'Bended', '0.60', '162', '2440', '165', 'End User', '1'),
(134, 'SPSMEU', 'Mirror 304', 'Misc', '0.40', 'NA', '1220', '3100', 'End User', '1'),
(135, 'SPSM40EU', 'Matt 304', 'Misc', '0.40', 'NA', '1220', '2600', 'End User', '1'),
(136, 'SPSM50EU', 'Matt 304', 'Misc', '0.50', 'NA', '1220', '3500', 'End User', '1'),
(137, 'SPSM60EU', 'Matt 304', 'Misc', '0.60', 'NA', '1220', '4100', 'End User', '1'),
(138, 'IF51EU', 'Insulation Foam 1-sided', 'Misc', '5', '1 meter', '', '1900', 'End User', '1'),
(139, 'IF52EU', 'Insulation Foam 2-sided', 'Misc', '5', '1 meter', '', '2650', 'End User', '1'),
(140, 'IF101EU', 'Insulation Foam 1-sided', 'Misc', '10', '1 meter', '', '3230', 'End User', '1'),
(141, 'IF102EU', 'Insulation Foam 2-sided', 'Misc', '10', '1 meter', '', '3980', 'End User', '1'),
(142, 'TS1EU', 'Tekscrew 2\"', 'Misc', '', '', '', '1.75', 'End User', '1'),
(143, 'TS2EU', 'Tekscrew 2-1/2\"', 'Misc', '', '', '', '1.75', 'End User', '1'),
(144, 'TS3EU', 'Tekscrew 3\"', 'Misc', '', '', '', '3', 'End User', '1'),
(145, 'TR35CN', 'Turin Rib 1220', 'Roofing', '0.35', '1130', '', '220', 'Contractor', NULL),
(146, 'TR40CN', 'Turin Rib 1220', 'Roofing', '0.40', '1130', '', '260', 'Contractor', NULL),
(147, 'TR50CN', 'Turin Rib 1220', 'Roofing', '0.50', '1130', '', '335', 'Contractor', NULL),
(148, 'TR60CN', 'Turin Rib 1220', 'Roofing', '0.60', '1130', '', '400', 'Contractor', NULL),
(149, 'CR35CN', 'Corrugated 1220', 'Roofing', '0.35', '1130', '', '220', 'Contractor', NULL),
(150, 'CR40CN', 'Corrugated 1220', 'Roofing', '0.40', '1130', '', '260', 'Contractor', NULL),
(151, 'CR50CN', 'Corrugated 1220', 'Roofing', '0.50', '1130', '', '335', 'Contractor', NULL),
(152, 'CR60CN', 'Corrugated 1220', 'Roofing', '0.60', '1130', '', '400', 'Contractor', NULL),
(153, 'GT40CN', 'Genova Tile', 'Roofing', '0.40', '1127', '', '300', 'Contractor', NULL),
(154, 'GT50CN', 'Genova Tile', 'Roofing', '0.50', '1127', '', '380', 'Contractor', NULL),
(155, 'GT60CN', 'Genova Tile', 'Roofing', '0.60', '1127', '', '455', 'Contractor', NULL),
(156, 'PD8080CN', 'Prime Deck 80,000psi', 'Roofing', '0.80', '995', '', '520', 'Contractor', NULL),
(157, 'PD80100CN', 'Prime Deck 80,000psi', 'Roofing', '1.00', '995', '', '650', 'Contractor', NULL),
(158, 'PD5080CN', 'Prime Deck 50,000psi', 'Roofing', '0.80', '995', '', '475', 'Contractor', NULL),
(159, 'PD50100CN', 'Prime Deck 50,000psi', 'Roofing', '1.00', '995', '', '590', 'Contractor', NULL),
(160, 'PC40CN', 'Prime Clad(Ordinary)', 'Roofing', '0.40', '255', '', '95', 'Contractor', NULL),
(161, 'PC50CN', 'Prime Clad(Ordinary)', 'Roofing', '0.50', '255', '', '105', 'Contractor', NULL),
(162, 'PC60CN', 'Prime Clad(Ordinary)', 'Roofing', '0.60', '255', '', '115', 'Contractor', NULL),
(163, 'PS4x8CN35', 'Plainsheet(4x8)', 'Bended', '0.35', '1220', '2440', '537', 'Contractor', NULL),
(164, 'PS4x8CN40', 'Plainsheet(4x8)', 'Bended', '0.40', '1220', '2440', '635', 'Contractor', NULL),
(165, 'PS4x8CN50', 'Plainsheet(4x8)', 'Bended', '0.50', '1220', '2440', '818', 'Contractor', NULL),
(166, 'PS4x8CN60', 'Plainsheet(4x8)', 'Bended', '0.60', '1220', '2440', '976', 'Contractor', NULL),
(167, 'RC4018OCN', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '305', 'Contractor', NULL),
(168, 'RC4018OCN', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '355', 'Contractor', NULL),
(169, 'RR4048OCN', 'Bended', 'Bended', '0.40', '1220', '2440', '670', 'Contractor', NULL),
(170, 'RR4048SCN', 'Bended', 'Bended', '0.40', '1220', '2440', '810', 'Contractor', NULL),
(171, 'RR5048OCN', 'Bended', 'Bended', '0.50', '1220', '2440', '850', 'Contractor', NULL),
(172, 'RR5048SCN', 'Bended', 'Bended', '0.50', '1220', '2440', '1010', 'Contractor', NULL),
(173, 'RR6048OCN', 'Bended', 'Bended', '0.60', '1220', '2440', '1015', 'Contractor', NULL),
(174, 'RR6048SCN', 'Bended', 'Bended', '0.60', '1220', '2440', '1180', 'Contractor', NULL),
(175, 'RR4036OCN', 'Bended', 'Bended', '0.40', '915', '2440', '540', 'Contractor', NULL),
(176, 'RR4036SCN', 'Bended', 'Bended', '0.40', '915', '2440', '615', 'Contractor', NULL),
(177, 'RR4032OCN', 'Bended', 'Bended', '0.40', '813', '2440', '460', 'Contractor', NULL),
(178, 'RR4032SCN', 'Bended', 'Bended', '0.40', '813', '2440', '550', 'Contractor', NULL),
(179, 'RR5032OCN', 'Bended', 'Bended', '0.50', '813', '2440', '580', 'Contractor', NULL),
(180, 'RR5032SCN', 'Bended', 'Bended', '0.50', '813', '2440', '685', 'Contractor', NULL),
(181, 'RR6032OCN', 'Bended', 'Bended', '0.60', '813', '2440', '686', 'Contractor', NULL),
(182, 'RR6032SCN', 'Bended', 'Bended', '0.60', '813', '2440', '800', 'Contractor', NULL),
(183, 'RR4030OCN', 'Bended', 'Bended', '0.40', '763', '2440', '435', 'Contractor', NULL),
(184, 'RR4030SCN', 'Bended', 'Bended', '0.40', '763', '2440', '475', 'Contractor', NULL),
(185, 'RR5030OCN', 'Bended', 'Bended', '0.50', '763', '2440', '546', 'Contractor', NULL),
(186, 'RR5030SCN', 'Bended', 'Bended', '0.50', '763', '2440', '590', 'Contractor', NULL),
(187, 'RR6030OCN', 'Bended', 'Bended', '0.60', '763', '2440', '645', 'Contractor', NULL),
(188, 'RR6030SCN', 'Bended', 'Bended', '0.60', '763', '2440', '690', 'Contractor', NULL),
(189, 'RR4024OCN', 'Bended', 'Bended', '0.40', '610', '2440', '355', 'Contractor', NULL),
(190, 'RR4024SCN', 'Bended', 'Bended', '0.40', '610', '2440', '400', 'Contractor', NULL),
(191, 'RR5024OCN', 'Bended', 'Bended', '0.50', '610', '2440', '445', 'Contractor', NULL),
(192, 'RR5024SCN', 'Bended', 'Bended', '0.50', '610', '2440', '490', 'Contractor', NULL),
(193, 'RR6024OCN', 'Bended', 'Bended', '0.60', '610', '2440', '525', 'Contractor', NULL),
(194, 'RR6024SCN', 'Bended', 'Bended', '0.60', '610', '2440', '570', 'Contractor', NULL),
(195, 'RR4018OCN', 'Bended', 'Bended', '0.40', '457', '2440', '290', 'Contractor', NULL),
(196, 'RR4018SCN', 'Bended', 'Bended', '0.40', '457', '2440', '340', 'Contractor', NULL),
(197, 'RR4016OCN', 'Bended', 'Bended', '0.40', '407', '2440', '250', 'Contractor', NULL),
(198, 'RR4016SCN', 'Bended', 'Bended', '0.40', '407', '2440', '295', 'Contractor', NULL),
(199, 'RR5016OCN', 'Bended', 'Bended', '0.50', '407', '2440', '310', 'Contractor', NULL),
(200, 'RR5016SCN', 'Bended', 'Bended', '0.50', '407', '2440', '355', 'Contractor', NULL),
(201, 'RR4012OCN', 'Bended', 'Bended', '0.40', '305', '2440', '195', 'Contractor', '1'),
(202, 'RR6012OCN', 'Bended', 'Bended', '0.60', '305', '2440', '280', 'Contractor', '1'),
(203, 'RR5012OEU', 'Bended', 'Bended', '0.50', '305', '2440', '240', 'Contractor', '1'),
(204, 'RR409OCN', 'Bended', 'Bended', '0.40', '229', '2440', '160', 'Contractor', '1'),
(205, 'RR408OCN', 'Bended', 'Bended', '0.40', '203', '2440', '145', 'Contractor', '1'),
(206, 'RR508OCN', 'Bended', 'Bended', '0.50', '203', '2440', '175', 'Contractor', '1'),
(207, 'RR608OCN', 'Bended', 'Bended', '0.60', '203', '2440', '200', 'Contractor', '1'),
(208, 'RR406OCN', 'Bended', 'Bended', '0.40', '152', '2440', '115', 'Contractor', '1'),
(209, 'RR506OCN', 'Bended', 'Bended', '0.50', '152', '2440', '140', 'Contractor', '1'),
(210, 'RR606OCN', 'Bended', 'Bended', '0.60', '152', '2440', '160', 'Contractor', '1'),
(211, 'SPSMCN', 'Mirror 304', 'Misc', '0.40', 'NA', '1220', '2900', 'Contractor', '1'),
(212, 'SPSM40CN', 'Matt 304', 'Misc', '0.40', 'NA', '1220', '2500', 'Contractor', '1'),
(213, 'SPSM50CN', 'Matt 304', 'Misc', '0.50', 'NA', '1220', '3300', 'Contractor', '1'),
(214, 'SPSM60CN', 'Matt 304', 'Misc', '0.60', 'NA', '1220', '3700', 'Contractor', '1'),
(215, 'IF51CN', 'Insulation Foam 1-sided', 'Misc', '5', '1 meter', '', '1800', 'Contractor', '1'),
(216, 'IF52CN', 'Insulation Foam 2-sided', 'Misc', '5', '1 meter', '', '2450', 'Contractor', '1'),
(217, 'IF101CN', 'Insulation Foam 1-sided', 'Misc', '10', '1 meter', '', '3030', 'Contractor', '1'),
(218, 'IF102CN', 'Insulation Foam 2-sided', 'Misc', '10', '1 meter', '', '3680', 'Contractor', '1'),
(219, 'TS1CN', 'Tekscrew 2\"', 'Misc', '', '', '', '1.75', 'Contractor', '1'),
(220, 'TS2CN', 'Tekscrew 2-1/2\"', 'Misc', '', '', '', '1.75', 'Contractor', '1'),
(221, 'TS3CN', 'Tekscrew 3\"', 'Misc', '', '', '', '3', 'Contractor', '1'),
(222, 'RR6016OCN', 'Bended', 'Bended', '0.60', '407', '2440', '360', 'Contractor', '1'),
(223, 'RR6016SEU', 'Bended', 'Bended', '0.60', '407', '2440', '420', 'End User', '1'),
(224, 'RR6016OEU', 'Bended', 'Bended', '0.60', '407', '2440', '380', 'End User', '1'),
(225, 'RR6016SCN', 'Bended', 'Bended', '0.60', '407', '2440', '405', 'Contractor', '1'),
(226, 'TR35HB', 'Turin Rib 1220', 'Roofing', '0.35', '1130', '', '220', 'Hardware-B', NULL),
(227, 'TR40HB', 'Turin Rib 1220', 'Roofing', '0.40', '1130', '', '255', 'Hardware-B', NULL),
(228, 'TR50HB', 'Turin Rib 1220', 'Roofing', '0.50', '1130', '', '325', 'Hardware-B', NULL),
(229, 'TR60HB', 'Turin Rib 1220', 'Roofing', '0.60', '1130', '', '390', 'Hardware-B', NULL),
(230, 'CR35HB', 'Corrugated 1220', 'Roofing', '0.35', '1130', '', '220', 'Hardware-B', NULL),
(231, 'CR40HB', 'Corrugated 1220', 'Roofing', '0.40', '1130', '', '255', 'Hardware-B', NULL),
(232, 'CR50HB', 'Corrugated 1220', 'Roofing', '0.50', '1130', '', '325', 'Hardware-B', NULL),
(233, 'CR60HB', 'Corrugated 1220', 'Roofing', '0.60', '1130', '', '390', 'Hardware-B', NULL),
(234, 'GT40HB', 'Genova Tile', 'Roofing', '0.40', '1127', '', '295', 'Hardware-B', NULL),
(235, 'GT50HB', 'Genova Tile', 'Roofing', '0.50', '1127', '', '370', 'Hardware-B', NULL),
(236, 'GT60HB', 'Genova Tile', 'Roofing', '0.60', '1127', '', '440', 'Hardware-B', NULL),
(237, 'PD8080HB', 'Prime Deck 80,000psi', 'Roofing', '0.80', '995', '', '510', 'Hardware-B', NULL),
(238, 'PD80100HB', 'Prime Deck 80,000psi', 'Roofing', '1.00', '995', '', '640', 'Hardware-B', NULL),
(239, 'PD5080HB', 'Prime Deck 50,000psi', 'Roofing', '0.80', '995', '', '460', 'Hardware-B', NULL),
(240, 'PD50100HB', 'Prime Deck 50,000psi', 'Roofing', '1.00', '995', '', '580', 'Hardware-B', NULL),
(241, 'PC40HB', 'Prime Clad(Ordinary)', 'Roofing', '0.40', '255', '', '90', 'Hardware-B', NULL),
(242, 'PC50HB', 'Prime Clad(Ordinary)', 'Roofing', '0.50', '255', '', '100', 'Hardware-B', NULL),
(243, 'PC60HB', 'Prime Clad(Ordinary)', 'Roofing', '0.60', '255', '', '110', 'Hardware-B', NULL),
(244, 'PS4x8HB35', 'Plainsheet(4x8)', 'Bended', '0.35', '1220', '2440', '537', 'Hardware-B', NULL),
(245, 'PS4x8HB40', 'Plainsheet(4x8)', 'Bended', '0.40', '1220', '2440', '625', 'Hardware-B', NULL),
(246, 'PS4x8HB50', 'Plainsheet(4x8)', 'Bended', '0.50', '1220', '2440', '793', 'Hardware-B', NULL),
(247, 'PS4x8HB60', 'Plainsheet(4x8)', 'Bended', '0.60', '1220', '2440', '955', 'Hardware-B', NULL),
(248, 'RC4018OHB', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '300', 'Hardware-B', NULL),
(249, 'RC4018OHB', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '350', 'Hardware-B', NULL),
(250, 'RR4048OHB', 'Bended', 'Bended', '0.40', '1220', '2440', '660', 'Hardware-B', NULL),
(251, 'RR4048SHB', 'Bended', 'Bended', '0.40', '1220', '2440', '795', 'Hardware-B', NULL),
(252, 'RR5048OHB', 'Bended', 'Bended', '0.50', '1220', '2440', '830', 'Hardware-B', NULL),
(253, 'RR5048SHB', 'Bended', 'Bended', '0.50', '1220', '2440', '995', 'Hardware-B', NULL),
(254, 'RR6048OHB', 'Bended', 'Bended', '0.60', '1220', '2440', '990', 'Hardware-B', NULL),
(255, 'RR6048SHB', 'Bended', 'Bended', '0.60', '1220', '2440', '1165', 'Hardware-B', NULL),
(256, 'RR4036OHB', 'Bended', 'Bended', '0.40', '915', '2440', '530', 'Hardware-B', NULL),
(257, 'RR4036SHB', 'Bended', 'Bended', '0.40', '915', '2440', '605', 'Hardware-B', NULL),
(258, 'RR4032OHB', 'Bended', 'Bended', '0.40', '813', '2440', '450', 'Hardware-B', NULL),
(259, 'RR4032SHB', 'Bended', 'Bended', '0.40', '813', '2440', '540', 'Hardware-B', NULL),
(260, 'RR5032OHB', 'Bended', 'Bended', '0.50', '813', '2440', '565', 'Hardware-B', NULL),
(261, 'RR5032SHB', 'Bended', 'Bended', '0.50', '813', '2440', '675', 'Hardware-B', NULL),
(262, 'RR6032OHB', 'Bended', 'Bended', '0.60', '813', '2440', '675', 'Hardware-B', NULL),
(263, 'RR6032SHB', 'Bended', 'Bended', '0.60', '813', '2440', '790', 'Hardware-B', NULL),
(264, 'RR4030OHB', 'Bended', 'Bended', '0.40', '763', '2440', '425', 'Hardware-B', NULL),
(265, 'RR4030SHB', 'Bended', 'Bended', '0.40', '763', '2440', '470', 'Hardware-B', NULL),
(266, 'RR5030OHB', 'Bended', 'Bended', '0.50', '763', '2440', '530', 'Hardware-B', NULL),
(267, 'RR5030SHB', 'Bended', 'Bended', '0.50', '763', '2440', '575', 'Hardware-B', NULL),
(268, 'RR6030OHB', 'Bended', 'Bended', '0.60', '763', '2440', '635', 'Hardware-B', NULL),
(269, 'RR6030SHB', 'Bended', 'Bended', '0.60', '763', '2440', '680', 'Hardware-B', NULL),
(270, 'RR4024OHB', 'Bended', 'Bended', '0.40', '610', '2440', '350', 'Hardware-B', NULL),
(271, 'RR4024SHB', 'Bended', 'Bended', '0.40', '610', '2440', '425395', 'Hardware-B', NULL),
(272, 'RR5024OHB', 'Bended', 'Bended', '0.50', '610', '2440', '435', 'Hardware-B', NULL),
(273, 'RR5024SHB', 'Bended', 'Bended', '0.50', '610', '2440', '480', 'Hardware-B', NULL),
(274, 'RR6024OHB', 'Bended', 'Bended', '0.60', '610', '2440', '515', 'Hardware-B', NULL),
(275, 'RR6024SHB', 'Bended', 'Bended', '0.60', '610', '2440', '560', 'Hardware-B', NULL),
(276, 'RR4018OHB', 'Bended', 'Bended', '0.40', '457', '2440', '285', 'Hardware-B', NULL),
(277, 'RR4018SHB', 'Bended', 'Bended', '0.40', '457', '2440', '330', 'Hardware-B', NULL),
(278, 'RR4016OHB', 'Bended', 'Bended', '0.40', '407', '2440', '245', 'Hardware-B', NULL),
(279, 'RR4016SHB', 'Bended', 'Bended', '0.40', '407', '2440', '290', 'Hardware-B', NULL),
(280, 'RR5016OHB', 'Bended', 'Bended', '0.50', '407', '2440', '300', 'Hardware-B', NULL),
(281, 'RR5016SHB', 'Bended', 'Bended', '0.50', '407', '2440', '345', 'Hardware-B', NULL),
(282, 'RR4012OHB', 'Bended', 'Bended', '0.40', '305', '2440', '190', 'Hardware-B', '1'),
(283, 'RR6012OHB', 'Bended', 'Bended', '0.60', '305', '2440', '275', 'Hardware-B', '1'),
(284, 'RR5012OHB', 'Bended', 'Bended', '0.50', '305', '2440', '235', 'Hardware-B', '1'),
(285, 'RR409OHB', 'Bended', 'Bended', '0.40', '229', '2440', '160', 'Hardware-B', '1'),
(286, 'RR408OHB', 'Bended', 'Bended', '0.40', '203', '2440', '140', 'Hardware-B', '1'),
(287, 'RR508OHB', 'Bended', 'Bended', '0.50', '203', '2440', '170', 'Hardware-B', '1'),
(288, 'RR608OHB', 'Bended', 'Bended', '0.60', '203', '2440', '195', 'Hardware-B', '1'),
(289, 'RR406OHB', 'Bended', 'Bended', '0.40', '162', '2440', '113', 'Hardware-B', '1'),
(290, 'RR506OHB', 'Bended', 'Bended', '0.50', '162', '2440', '135', 'Hardware-B', '1'),
(291, 'RR606OHB', 'Bended', 'Bended', '0.60', '162', '2440', '155', 'Hardware-B', '1'),
(292, 'SPSMHB', 'Mirror 304', 'Misc', '0.40', 'NA', '1220', '2800', 'Hardware-B', '1'),
(293, 'SPSM40HB', 'Matt 304', 'Misc', '0.40', 'NA', '1220', '2400', 'Hardware-B', '1'),
(294, 'SPSM50HB', 'Matt 304', 'Misc', '0.50', 'NA', '1220', '3200', 'Hardware-B', '1'),
(295, 'SPSM60HB', 'Matt 304', 'Misc', '0.60', 'NA', '1220', '3600', 'Hardware-B', '1'),
(296, 'IF51HB', 'Insulation Foam 1-sided', 'Misc', '5', '1 meter', '', '1700', 'Hardware-B', '1'),
(297, 'IF52HB', 'Insulation Foam 2-sided', 'Misc', '5', '1 meter', '', '2250', 'Hardware-B', '1'),
(298, 'IF101HB', 'Insulation Foam 1-sided', 'Misc', '10', '1 meter', '', '2830', 'Hardware-B', '1'),
(299, 'IF102HB', 'Insulation Foam 2-sided', 'Misc', '10', '1 meter', '', '3380', 'Hardware-B', '1'),
(300, 'TS1HB', 'Tekscrew 2\"', 'Misc', '', '', '', '1.75', 'Hardware-B', '1'),
(301, 'TS2HB', 'Tekscrew 2-1/2\"', 'Misc', '', '', '', '1.75', 'Hardware-B', '1'),
(302, 'TS3HB', 'Tekscrew 3\"', 'Misc', '', '', '', '3', 'Hardware-B', '1'),
(303, 'TR35HA', 'Turin Rib 1220', 'Roofing', '0.35', '1130', '', '220', 'Hardware-A', NULL),
(304, 'TR40HA', 'Turin Rib 1220', 'Roofing', '0.40', '1130', '', '245', 'Hardware-A', NULL),
(305, 'TR50HA', 'Turin Rib 1220', 'Roofing', '0.50', '1130', '', '315', 'Hardware-A', NULL),
(306, 'TR60HA', 'Turin Rib 1220', 'Roofing', '0.60', '1130', '', '380', 'Hardware-A', NULL),
(307, 'CR35HA', 'Corrugated 1220', 'Roofing', '0.35', '1130', '', '220', 'Hardware-A', NULL),
(308, 'CR40HA', 'Corrugated 1220', 'Roofing', '0.40', '1130', '', '245', 'Hardware-A', NULL),
(309, 'CR50HA', 'Corrugated 1220', 'Roofing', '0.50', '1130', '', '315', 'Hardware-A', NULL),
(310, 'CR60HA', 'Corrugated 1220', 'Roofing', '0.60', '1130', '', '380', 'Hardware-A', NULL),
(311, 'GT40HA', 'Genova Tile', 'Roofing', '0.40', '1127', '', '285', 'Hardware-A', NULL),
(312, 'GT50HA', 'Genova Tile', 'Roofing', '0.50', '1127', '', '369', 'Hardware-A', NULL),
(313, 'GT60HA', 'Genova Tile', 'Roofing', '0.60', '1127', '', '430', 'Hardware-A', NULL),
(314, 'PD8080HA', 'Prime Deck 80,000psi', 'Roofing', '0.80', '995', '', '490', 'Hardware-A', NULL),
(315, 'PD80100HA', 'Prime Deck 80,000psi', 'Roofing', '1.00', '995', '', '610', 'Hardware-A', NULL),
(316, 'PD5080HA', 'Prime Deck 50,000psi', 'Roofing', '0.80', '995', '', '445', 'Hardware-A', NULL),
(317, 'PD50100HA', 'Prime Deck 50,000psi', 'Roofing', '1.00', '995', '', '550', 'Hardware-A', NULL),
(318, 'PC40HA', 'Prime Clad(Ordinary)', 'Roofing', '0.40', '255', '', '85', 'Hardware-A', NULL),
(319, 'PC50HA', 'Prime Clad(Ordinary)', 'Roofing', '0.50', '255', '', '95', 'Hardware-A', NULL),
(320, 'PC60HA', 'Prime Clad(Ordinary)', 'Roofing', '0.60', '255', '', '105', 'Hardware-A', NULL),
(321, 'PS4x8HA35', 'Plainsheet(4x8)', 'Bended', '0.35', '1220', '2440', '537', 'Hardware-A', NULL),
(322, 'PS4x8HA40', 'Plainsheet(4x8)', 'Bended', '0.40', '1220', '2440', '600', 'Hardware-A', NULL),
(323, 'PS4x8HA50', 'Plainsheet(4x8)', 'Bended', '0.50', '1220', '2440', '770', 'Hardware-A', NULL),
(324, 'PS4x8HA60', 'Plainsheet(4x8)', 'Bended', '0.60', '1220', '2440', '930', 'Hardware-A', NULL),
(325, 'RC4018OHA', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '290', 'Hardware-A', NULL),
(326, 'RC4018OHA', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '340', 'Hardware-A', NULL),
(327, 'RR4048OHA', 'Bended', 'Bended', '0.40', '1220', '2440', '635', 'Hardware-A', NULL),
(328, 'RR4048SHA', 'Bended', 'Bended', '0.40', '1220', '2440', '755', 'Hardware-A', NULL),
(329, 'RR5048OHA', 'Bended', 'Bended', '0.50', '1220', '2440', '805', 'Hardware-A', NULL),
(330, 'RR5048SHA', 'Bended', 'Bended', '0.50', '1220', '2440', '930', 'Hardware-A', NULL),
(331, 'RR6048OHA', 'Bended', 'Bended', '0.60', '1220', '2440', '965', 'Hardware-A', NULL),
(332, 'RR6048SHA', 'Bended', 'Bended', '0.60', '1220', '2440', '1085', 'Hardware-A', NULL),
(333, 'RR4036OHA', 'Bended', 'Bended', '0.40', '915', '2440', '510', 'Hardware-A', NULL),
(334, 'RR4036SHA', 'Bended', 'Bended', '0.40', '915', '2440', '575', 'Hardware-A', NULL),
(335, 'RR4032OHA', 'Bended', 'Bended', '0.40', '813', '2440', '435', 'Hardware-A', NULL),
(336, 'RR4032SHA', 'Bended', 'Bended', '0.40', '813', '2440', '515', 'Hardware-A', NULL),
(337, 'RR5032OHA', 'Bended', 'Bended', '0.50', '813', '2440', '550', 'Hardware-A', NULL),
(338, 'RR5032SHA', 'Bended', 'Bended', '0.50', '813', '2440', '630', 'Hardware-A', NULL),
(339, 'RR6032OHA', 'Bended', 'Bended', '0.60', '813', '2440', '655', 'Hardware-A', NULL),
(340, 'RR6032SHA', 'Bended', 'Bended', '0.60', '813', '2440', '735', 'Hardware-A', NULL),
(341, 'RR4030OHA', 'Bended', 'Bended', '0.40', '763', '2440', '410', 'Hardware-A', NULL),
(342, 'RR4030SHA', 'Bended', 'Bended', '0.40', '763', '2440', '455', 'Hardware-A', NULL),
(343, 'RR5030OHA', 'Bended', 'Bended', '0.50', '763', '2440', '520', 'Hardware-A', NULL),
(344, 'RR5030SHA', 'Bended', 'Bended', '0.50', '763', '2440', '560', 'Hardware-A', NULL),
(345, 'RR6030OHA', 'Bended', 'Bended', '0.60', '763', '2440', '620', 'Hardware-A', NULL),
(346, 'RR6030SHA', 'Bended', 'Bended', '0.60', '763', '2440', '660', 'Hardware-A', NULL),
(347, 'RR4024OHA', 'Bended', 'Bended', '0.40', '610', '2440', '335', 'Hardware-A', NULL),
(348, 'RR4024SHA', 'Bended', 'Bended', '0.40', '610', '2440', '380', 'Hardware-A', NULL),
(349, 'RR5024OHA', 'Bended', 'Bended', '0.50', '610', '2440', '420', 'Hardware-A', NULL),
(350, 'RR5024SHA', 'Bended', 'Bended', '0.50', '610', '2440', '465', 'Hardware-A', NULL),
(351, 'RR6024OHA', 'Bended', 'Bended', '0.60', '610', '2440', '500', 'Hardware-A', NULL),
(352, 'RR6024SHA', 'Bended', 'Bended', '0.60', '610', '2440', '545', 'Hardware-A', NULL),
(353, 'RR4018OHA', 'Bended', 'Bended', '0.40', '457', '2440', '275', 'Hardware-A', NULL),
(354, 'RR4018SHA', 'Bended', 'Bended', '0.40', '457', '2440', '320', 'Hardware-A', NULL),
(355, 'RR4016OHA', 'Bended', 'Bended', '0.40', '407', '2440', '235', 'Hardware-A', NULL),
(356, 'RR4016SHA', 'Bended', 'Bended', '0.40', '407', '2440', '280', 'Hardware-A', NULL),
(357, 'RR5016OHA', 'Bended', 'Bended', '0.50', '407', '2440', '290', 'Hardware-A', NULL),
(358, 'RR5016SHA', 'Bended', 'Bended', '0.50', '407', '2440', '340', 'Hardware-A', NULL),
(359, 'RR4012OHA', 'Bended', 'Bended', '0.40', '305', '2440', '185', 'Hardware-A', '1'),
(360, 'RR6012OHA', 'Bended', 'Bended', '0.60', '305', '2440', '230', 'Hardware-A', '1'),
(361, 'RR5012OHA', 'Bended', 'Bended', '0.50', '305', '2440', '270', 'Hardware-A', '1'),
(362, 'RR409OHA', 'Bended', 'Bended', '0.40', '229', '2440', '155', 'Hardware-A', '1'),
(363, 'RR408OHA', 'Bended', 'Bended', '0.40', '203', '2440', '135', 'Hardware-A', '1'),
(364, 'RR508OHA', 'Bended', 'Bended', '0.50', '203', '2440', '165', 'Hardware-A', '1'),
(365, 'RR608OHA', 'Bended', 'Bended', '0.60', '203', '2440', '190', 'Hardware-A', '1'),
(366, 'RR406OHA', 'Bended', 'Bended', '0.40', '162', '2440', '110', 'Hardware-A', '1'),
(367, 'RR506OHA', 'Bended', 'Bended', '0.50', '162', '2440', '132', 'Hardware-A', '1'),
(368, 'RR606OHA', 'Bended', 'Bended', '0.60', '162', '2440', '152', 'Hardware-A', '1'),
(369, 'SPSMHA', 'Mirror 304', 'Misc', '0.40', 'NA', '1220', '2700', 'Hardware-A', '1'),
(370, 'SPSM40HA', 'Matt 304', 'Misc', '0.40', 'NA', '1220', '2300', 'Hardware-A', '1'),
(371, 'SPSM50HA', 'Matt 304', 'Misc', '0.50', 'NA', '1220', '3100', 'Hardware-A', '1'),
(372, 'SPSM60HA', 'Matt 304', 'Misc', '0.60', 'NA', '1220', '3500', 'Hardware-A', '1'),
(373, 'IF51HA', 'Insulation Foam 1-sided', 'Misc', '5', '1 meter', '', '1600', 'Hardware-A', '1'),
(374, 'IF52HA', 'Insulation Foam 2-sided', 'Misc', '5', '1 meter', '', '2100', 'Hardware-A', '1'),
(375, 'IF101HA', 'Insulation Foam 1-sided', 'Misc', '10', '1 meter', '', '2600', 'Hardware-A', '1'),
(376, 'IF102HA', 'Insulation Foam 2-sided', 'Misc', '10', '1 meter', '', '3100', 'Hardware-A', '1'),
(380, 'TR35H', 'Turin Rib 1220', 'Roofing', '0.35', '1130', '', '218', 'Hardware', NULL),
(381, 'TR40H', 'Turin Rib 1220', 'Roofing', '0.40', '1130', '', '240', 'Hardware', NULL),
(382, 'TR50H', 'Turin Rib 1220', 'Roofing', '0.50', '1130', '', '310', 'Hardware', NULL),
(383, 'TR60H', 'Turin Rib 1220', 'Roofing', '0.60', '1130', '', '375', 'Hardware', NULL),
(384, 'CR35H', 'Corrugated 1220', 'Roofing', '0.35', '1130', '', '218', 'Hardware', NULL),
(385, 'CR40H', 'Corrugated 1220', 'Roofing', '0.40', '1130', '', '230', 'Hardware', NULL),
(386, 'CR50H', 'Corrugated 1220', 'Roofing', '0.50', '1130', '', '310', 'Hardware', NULL),
(387, 'CR60H', 'Corrugated 1220', 'Roofing', '0.60', '1130', '', '375', 'Hardware', NULL),
(388, 'GT40H', 'Genova Tile', 'Roofing', '0.40', '1127', '', '275', 'Hardware', NULL),
(389, 'GT50H', 'Genova Tile', 'Roofing', '0.50', '1127', '', '355', 'Hardware', NULL),
(390, 'GT60H', 'Genova Tile', 'Roofing', '0.60', '1127', '', '425', 'Hardware', NULL),
(391, 'PD8080H', 'Prime Deck 80,000psi', 'Roofing', '0.80', '995', '', '480', 'Hardware', NULL),
(392, 'PD80100H', 'Prime Deck 80,000psi', 'Roofing', '1.00', '995', '', '600', 'Hardware', NULL),
(393, 'PD5080H', 'Prime Deck 50,000psi', 'Roofing', '0.80', '995', '', '435', 'Hardware', NULL),
(394, 'PD50100H', 'Prime Deck 50,000psi', 'Roofing', '1.00', '995', '', '540', 'Hardware', NULL),
(395, 'PC40H', 'Prime Clad(Ordinary)', 'Roofing', '0.40', '255', '', '80', 'Hardware', NULL),
(396, 'PC50H', 'Prime Clad(Ordinary)', 'Roofing', '0.50', '255', '', '90', 'Hardware', NULL),
(397, 'PC60H', 'Prime Clad(Ordinary)', 'Roofing', '0.60', '255', '', '100', 'Hardware', NULL),
(398, 'PS4x8H35', 'Plainsheet(4x8)', 'Bended', '0.35', '1220', '2440', '532', 'Hardware', NULL),
(399, 'PS4x8H40', 'Plainsheet(4x8)', 'Bended', '0.40', '1220', '2440', '586', 'Hardware', NULL),
(400, 'PS4x8H50', 'Plainsheet(4x8)', 'Bended', '0.50', '1220', '2440', '757', 'Hardware', NULL),
(401, 'PS4x8H60', 'Plainsheet(4x8)', 'Bended', '0.60', '1220', '2440', '915', 'Hardware', NULL),
(402, 'RC4018OH', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '290', 'Hardware', NULL),
(403, 'RC4018OH', 'Ridge Cap', 'Bended', '0.40', '457', '2440', '340', 'Hardware', NULL),
(404, 'RR4048OH', 'Bended', 'Bended', '0.40', '1220', '2440', '625', 'Hardware', NULL),
(405, 'RR4048SH', 'Bended', 'Bended', '0.40', '1220', '2440', '725', 'Hardware', NULL),
(406, 'RR5048OH', 'Bended', 'Bended', '0.50', '1220', '2440', '800', 'Hardware', NULL),
(407, 'RR5048SH', 'Bended', 'Bended', '0.50', '1220', '2440', '900', 'Hardware', NULL),
(408, 'RR6048OH', 'Bended', 'Bended', '0.60', '1220', '2440', '950', 'Hardware', NULL),
(409, 'RR6048SH', 'Bended', 'Bended', '0.60', '1220', '2440', '1000', 'Hardware', NULL),
(410, 'RR4036OH', 'Bended', 'Bended', '0.40', '915', '2440', '510', 'Hardware', NULL),
(411, 'RR4036SH', 'Bended', 'Bended', '0.40', '915', '2440', '560', 'Hardware', NULL),
(412, 'RR4032OH', 'Bended', 'Bended', '0.40', '813', '2440', '430', 'Hardware', NULL),
(413, 'RR4032SH', 'Bended', 'Bended', '0.40', '813', '2440', '495', 'Hardware', NULL),
(414, 'RR5032OH', 'Bended', 'Bended', '0.50', '813', '2440', '540', 'Hardware', NULL),
(415, 'RR5032SH', 'Bended', 'Bended', '0.50', '813', '2440', '610', 'Hardware', NULL),
(416, 'RR6032OH', 'Bended', 'Bended', '0.60', '813', '2440', '645', 'Hardware', NULL),
(417, 'RR6032SH', 'Bended', 'Bended', '0.60', '813', '2440', '715', 'Hardware', NULL),
(418, 'RR4030OH', 'Bended', 'Bended', '0.40', '763', '2440', '405', 'Hardware', NULL),
(419, 'RR4030SH', 'Bended', 'Bended', '0.40', '763', '2440', '450', 'Hardware', NULL),
(420, 'RR5030OH', 'Bended', 'Bended', '0.50', '763', '2440', '510', 'Hardware', NULL),
(421, 'RR5030SH', 'Bended', 'Bended', '0.50', '763', '2440', '555', 'Hardware', NULL),
(422, 'RR6030OH', 'Bended', 'Bended', '0.60', '763', '2440', '610', 'Hardware', NULL),
(423, 'RR6030SH', 'Bended', 'Bended', '0.60', '763', '2440', '655', 'Hardware', NULL),
(424, 'RR4024OH', 'Bended', 'Bended', '0.40', '610', '2440', '330', 'Hardware', NULL),
(425, 'RR4024SH', 'Bended', 'Bended', '0.40', '610', '2440', '375', 'Hardware', NULL),
(426, 'RR5024OH', 'Bended', 'Bended', '0.50', '610', '2440', '415', 'Hardware', NULL),
(427, 'RR5024SH', 'Bended', 'Bended', '0.50', '610', '2440', '460', 'Hardware', NULL),
(428, 'RR6024OH', 'Bended', 'Bended', '0.60', '610', '2440', '495', 'Hardware', NULL),
(429, 'RR6024SH', 'Bended', 'Bended', '0.60', '610', '2440', '540', 'Hardware', NULL),
(430, 'RR4018OH', 'Bended', 'Bended', '0.40', '457', '2440', '275', 'Hardware', NULL),
(431, 'RR4018SH', 'Bended', 'Bended', '0.40', '457', '2440', '320', 'Hardware', NULL),
(432, 'RR4016OH', 'Bended', 'Bended', '0.40', '407', '2440', '230', 'Hardware', NULL),
(433, 'RR4016SH', 'Bended', 'Bended', '0.40', '407', '2440', '275', 'Hardware', NULL),
(434, 'RR5016OH', 'Bended', 'Bended', '0.50', '407', '2440', '290', 'Hardware', NULL),
(435, 'RR5016SH', 'Bended', 'Bended', '0.50', '407', '2440', '335', 'Hardware', NULL),
(436, 'RR4012OH', 'Bended', 'Bended', '0.40', '305', '2440', '185', 'Hardware', '1'),
(437, 'RR6012OH', 'Bended', 'Bended', '0.60', '305', '2440', '265', 'Hardware', '1'),
(438, 'RR5012OH', 'Bended', 'Bended', '0.50', '305', '2440', '225', 'Hardware', '1'),
(439, 'RR409OH', 'Bended', 'Bended', '0.40', '229', '2440', '155', 'Hardware', '1'),
(440, 'RR408OH', 'Bended', 'Bended', '0.40', '203', '2440', '135', 'Hardware', '1'),
(441, 'RR508OH', 'Bended', 'Bended', '0.50', '203', '2440', '165', 'Hardware', '1'),
(442, 'RR608OH', 'Bended', 'Bended', '0.60', '203', '2440', '190', 'Hardware', '1'),
(443, 'RR406OH', 'Bended', 'Bended', '0.40', '162', '2440', '110', 'Hardware', '1'),
(444, 'RR506OH', 'Bended', 'Bended', '0.50', '162', '2440', '130', 'Hardware', '1'),
(445, 'RR606OH', 'Bended', 'Bended', '0.60', '162', '2440', '150', 'Hardware', '1'),
(446, 'SPSMH', 'Mirror 304', 'Misc', '0.40', 'NA', '1220', '2600', 'Hardware', '1'),
(447, 'SPSM40H', 'Matt 304', 'Misc', '0.40', 'NA', '1220', '2200', 'Hardware', '1'),
(448, 'SPSM50H', 'Matt 304', 'Misc', '0.50', 'NA', '1220', '3000', 'Hardware', '1'),
(449, 'SPSM60H', 'Matt 304', 'Misc', '0.60', 'NA', '1220', '3400', 'Hardware', '1'),
(450, 'IF51H', 'Insulation Foam 1-sided', 'Misc', '5', '1 meter', '', '1600', 'Hardware', '1'),
(451, 'IF52H', 'Insulation Foam 2-sided', 'Misc', '5', '1 meter', '', '2100', 'Hardware', '1'),
(452, 'IF101H', 'Insulation Foam 1-sided', 'Misc', '10', '1 meter', '', '2600', 'Hardware', '1'),
(453, 'IF102H', 'Insulation Foam 2-sided', 'Misc', '10', '1 meter', '', '3100', 'Hardware', '1'),
(454, '', 'Plain Sheet', 'Roofing', '0.40', '1220', '', '685', 'End User', '1'),
(455, '', 'Plain Sheet', 'Roofing', '0.40', '1220', '', '635', 'Contractor', '1');

-- --------------------------------------------------------

--
-- Table structure for table `salesitem`
--

CREATE TABLE `salesitem` (
  `id` int(255) NOT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `itemName` varchar(255) DEFAULT NULL,
  `Thickness` varchar(255) DEFAULT NULL,
  `Width` varchar(255) DEFAULT NULL,
  `Length` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `LMS` varchar(255) DEFAULT NULL,
  `salesorderno` varchar(255) DEFAULT NULL,
  `Yield` varchar(255) DEFAULT NULL,
  `Tonnage` varchar(255) DEFAULT NULL,
  `CoilNo` varchar(255) DEFAULT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `JO` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Customer` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `Unit` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `bendedCost` varchar(255) DEFAULT NULL,
  `bendedTotal` varchar(255) DEFAULT NULL,
  `commissionCost` varchar(255) DEFAULT NULL,
  `commissionTotal` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salesitem2`
--

CREATE TABLE `salesitem2` (
  `id` int(255) NOT NULL,
  `Quantity` varchar(255) DEFAULT NULL,
  `itemName` varchar(255) DEFAULT NULL,
  `Thickness` varchar(255) DEFAULT NULL,
  `Width` varchar(255) DEFAULT NULL,
  `Length` varchar(255) DEFAULT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `LMS` varchar(255) DEFAULT NULL,
  `salesorderno` varchar(255) DEFAULT NULL,
  `Yield` varchar(255) DEFAULT NULL,
  `Tonnage` varchar(255) DEFAULT NULL,
  `CoilNo` varchar(255) DEFAULT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `JO` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Customer` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `Unit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salesorder`
--

CREATE TABLE `salesorder` (
  `id` int(255) NOT NULL,
  `FullName` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `TelNo` varchar(255) DEFAULT NULL,
  `Project` varchar(255) DEFAULT NULL,
  `DateCreated` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `SQno` varchar(255) DEFAULT NULL,
  `POno` varchar(255) DEFAULT NULL,
  `Color` varchar(255) DEFAULT NULL,
  `AgreedAmount` varchar(255) DEFAULT NULL,
  `Remarks` varchar(255) DEFAULT NULL,
  `Pickup` varchar(255) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `PrintStatus` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `SalesInvoice` varchar(255) DEFAULT NULL,
  `ContractorAgreedAmount` varchar(255) DEFAULT NULL,
  `DP` varchar(255) DEFAULT NULL,
  `Balance` varchar(255) DEFAULT NULL,
  `DeliveryCharge` varchar(255) DEFAULT NULL,
  `Chq` varchar(255) DEFAULT NULL,
  `lastpayment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salesorder`
--

INSERT INTO `salesorder` (`id`, `FullName`, `Address`, `TelNo`, `Project`, `DateCreated`, `Date`, `SR`, `SQno`, `POno`, `Color`, `AgreedAmount`, `Remarks`, `Pickup`, `PaymentStatus`, `PrintStatus`, `Status`, `SalesInvoice`, `ContractorAgreedAmount`, `DP`, `Balance`, `DeliveryCharge`, `Chq`, `lastpayment`) VALUES
(1, '', '', '', '', '', '2020-01-04', '', '', '', '', '', '', '', '', 'Not Printed', '', '', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `firstname`, `lastname`, `address`) VALUES
(1, 'asd', 'asd', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `Fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `UserType` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `Fullname`, `username`, `password`, `UserType`) VALUES
(3, 'lee macale', 'leemacale', '12345', 'Sales Rep'),
(4, 'Alyssa Macahilas', 'Alyssa', '123', 'Sales Rep'),
(5, 'Alene Guino', 'Alene', '456', 'Admin'),
(7, 'Rina Catalla', 'Rina', '789', 'Sales Rep'),
(9, 'Daisy', 'Daisy', 'Padrepio', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitylist`
--
ALTER TABLE `activitylist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bendedlist`
--
ALTER TABLE `bendedlist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gatepass`
--
ALTER TABLE `gatepass`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventorylist`
--
ALTER TABLE `inventorylist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobitem`
--
ALTER TABLE `jobitem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `joborder`
--
ALTER TABLE `joborder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `misclist`
--
ALTER TABLE `misclist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pricelist`
--
ALTER TABLE `pricelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesitem`
--
ALTER TABLE `salesitem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesitem2`
--
ALTER TABLE `salesitem2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salesorder`
--
ALTER TABLE `salesorder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitylist`
--
ALTER TABLE `activitylist`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bendedlist`
--
ALTER TABLE `bendedlist`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=499;

--
-- AUTO_INCREMENT for table `gatepass`
--
ALTER TABLE `gatepass`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventorylist`
--
ALTER TABLE `inventorylist`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;

--
-- AUTO_INCREMENT for table `jobitem`
--
ALTER TABLE `jobitem`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `joborder`
--
ALTER TABLE `joborder`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `misclist`
--
ALTER TABLE `misclist`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `pricelist`
--
ALTER TABLE `pricelist`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=456;

--
-- AUTO_INCREMENT for table `salesitem`
--
ALTER TABLE `salesitem`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salesitem2`
--
ALTER TABLE `salesitem2`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `salesorder`
--
ALTER TABLE `salesorder`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
